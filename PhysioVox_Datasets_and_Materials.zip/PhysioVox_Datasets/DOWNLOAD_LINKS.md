# PhysioVox Datasets — Download Links

## VOICED (Voice ICar fEDerico II Database)
- Official: https://physionet.org/content/voiced/1.0.0/
- Direct ZIP: https://physionet.org/content/voiced/get-zip/1.0.0/
- DOI: https://doi.org/10.13026/C25Q2N
- wget command:
    wget -r -N -c -np https://physionet.org/files/voiced/1.0.0/
- AWS S3:
    aws s3 sync --no-sign-request s3://physionet-open/voiced/1.0.0/ ./VOICED/

## SVD (Saarbruecken Voice Database)
- Official: https://stimmdb.coli.uni-saarland.de/
- Zenodo mirror: https://zenodo.org/records/16874898
- Notes: registration may be required on the Saarland portal; use the
  Zenodo mirror for batch download.

## VocalSet (Northwestern University)
- Zenodo (v1.2): https://zenodo.org/record/1442513
- Direct ZIP: https://zenodo.org/record/1442513/files/VocalSet1-2.zip
- DOI: https://doi.org/10.5281/zenodo.1442513
- License: CC BY 4.0

## NHSS (NUS-HLT Speak-Sing Database)
- Official: https://hltnus.github.io/NHSSDatabase/
- Paper: https://arxiv.org/abs/2012.00337
- Notes: request access via the NUS HLT laboratory webpage.

## OpenSinger
- GitHub: https://github.com/Multi-Singer/Multi-Singer.github.io
- Project page: https://multi-singer.github.io/
- License: CC BY-NC-SA 4.0

## After Download — Recommended Verification

```bash
python verify_datasets.py \
    --voiced     /path/to/VOICED/voiced-1.0.0 \
    --svd        /path/to/SVD \
    --vocalset   /path/to/VocalSet/VocalSet1-2 \
    --nhss       /path/to/NHSS_Database \
    --opensinger /path/to/OpenSinger
```

The script counts the relevant files (audio, EGG, headers, annotations) in
each dataset root and reports whether the layout matches the structure
expected by the PhysioVox data loaders.
