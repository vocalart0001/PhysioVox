"""
Dataset preparation helper for PhysioVox.

After downloading the five source corpora from their official providers,
run this script to verify that the local directory layout matches the
structure expected by the PhysioVox data loaders. The script counts the
relevant files in each dataset and prints a readiness report.
"""

import argparse
import os
from pathlib import Path
from typing import Dict, Tuple


def _count(root: str, patterns: Tuple[str, ...]) -> int:
    if not root or not os.path.isdir(root):
        return 0
    total = 0
    for pat in patterns:
        total += sum(1 for _ in Path(root).rglob(pat))
    return total


def verify_layout(roots: Dict[str, str]) -> Dict[str, Dict[str, int]]:
    """Counts the expected files inside each dataset root."""
    report: Dict[str, Dict[str, int]] = {}

    if roots.get("voiced"):
        report["VOICED"] = {
            ".hea (WFDB header)":    _count(roots["voiced"], ("voice*.hea",)),
            ".dat (binary signal)":  _count(roots["voiced"], ("voice*.dat",)),
            "-info.txt (metadata)":  _count(roots["voiced"], ("voice*-info.txt",)),
        }

    if roots.get("svd"):
        report["SVD"] = {
            ".nsp (audio)":            _count(roots["svd"], ("*.nsp",)),
            ".egg (laryngograph)":     _count(roots["svd"], ("*.egg",)),
            "session-info.txt":        _count(roots["svd"], ("*session-info.txt",)),
        }

    if roots.get("vocalset"):
        report["VocalSet"] = {
            ".wav (recordings)":         _count(roots["vocalset"], ("*.wav",)),
            "readme-anon.txt":           _count(roots["vocalset"], ("readme-anon.txt",)),
            "train/test split files":   _count(roots["vocalset"], ("train_singers_technique.txt", "test_singers_technique.txt")),
        }

    if roots.get("nhss"):
        report["NHSS"] = {
            "Song.wav (sung audio)":   _count(roots["nhss"], ("Song.wav",)),
            "Speech.wav (read audio)": _count(roots["nhss"], ("Speech.wav",)),
            ".TextGrid (annotation)":  _count(roots["nhss"], ("*.TextGrid",)),
            ".lab (phoneme labels)":   _count(roots["nhss"], ("*.lab",)),
        }

    if roots.get("opensinger"):
        report["OpenSinger"] = {
            ".wav (dry vocals)":  _count(roots["opensinger"], ("*.wav",)),
            "README.md":          _count(roots["opensinger"], ("README.md",)),
        }

    return report


def print_report(report: Dict[str, Dict[str, int]]) -> None:
    print("=" * 72)
    print("PhysioVox dataset layout verification report")
    print("=" * 72)
    for dataset, counts in report.items():
        print(f"\n  {dataset}")
        for label, n in counts.items():
            status = "OK " if n > 0 else "-- "
            print(f"    [{status}] {label:35s} : {n} files")
    print()
    print("=" * 72)
    print("Verification complete.")
    print("=" * 72)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Verify dataset directory layouts before running PhysioVox."
    )
    parser.add_argument("--voiced", type=str, default="")
    parser.add_argument("--svd", type=str, default="")
    parser.add_argument("--vocalset", type=str, default="")
    parser.add_argument("--nhss", type=str, default="")
    parser.add_argument("--opensinger", type=str, default="")
    args = parser.parse_args()

    roots = {
        "voiced": args.voiced,
        "svd": args.svd,
        "vocalset": args.vocalset,
        "nhss": args.nhss,
        "opensinger": args.opensinger,
    }
    report = verify_layout(roots)
    print_report(report)


if __name__ == "__main__":
    main()
