# PhysioVox Datasets — Download and Metadata

This package documents the five publicly available datasets used to train
and evaluate PhysioVox. It contains a single Excel workbook with twelve
sheets covering download links, sample-level metadata, file-type catalogues,
and example file structures for each dataset.

## Contents

- `PhysioVox_Datasets_Metadata.xlsx` — The master workbook (12 sheets):
  - `Overview` — Cross-dataset summary table with totals and role assignment.
  - `VOICED_208` — Per-subject metadata for the VOICED clinical corpus
    (age, gender, diagnosis, VHI/RSI scores, lifestyle factors).
  - `SVD_2225` — Per-session metadata for the Saarbruecken Voice Database
    (subject ID, session, gender, age, pathology codes).
  - `VocalSet_20` — Per-singer demographics and per-technique counts for
    the 20-singer / 17-technique VocalSet corpus.
  - `NHSS_10` — Per-singer demographics and per-song annotation availability
    for the NHSS speech-singing parallel database.
  - `OpenSinger_66` — Per-singer entries for the OpenSinger Chinese vocal
    corpus subset used in this work.
  - `File_Types_All` — Catalogue of all 34 file types across the five
    datasets (audio, EGG, text labels, alignment, headers).
  - `VOICED_FileStructure` — WFDB layout with real `.hea` and `-info.txt`
    examples.
  - `SVD_FileStructure` — `.nsp` and `.egg` synchronous-recording layout
    with real session-info field listings.
  - `VocalSet_FileStructure` — Five-field filename convention, full
    `readme-anon.txt` mapping, and the three official organisation modes.
  - `NHSS_FileStructure` — Six-component per-song folder layout, with
    `Song.TextGrid` (Praat utterance + word tiers) and `.lab` (HTK
    phoneme-level) example contents.
  - `OpenSinger_FileStructure` — Dual-root (`MaleSinger/`, `WomanRaw/`)
    directory layout with segment naming and README field listings.

## Datasets Used

| Dataset | Role | Subjects | Duration | EGG | License |
|---|---|---|---|---|---|
| VOICED | Pretraining | 208 | 0.4 h | Yes | ODC Attribution |
| SVD | Pretraining | 2225 sessions | 15.3 h | Yes | Academic use |
| VocalSet | Fine-tuning + 17-class classification | 20 singers | 9.8 h | No | CC BY 4.0 |
| NHSS | Cross-dataset zero-shot test | 10 singers | 7.2 h | No | Academic use |
| OpenSinger | Cross-dataset zero-shot test | 66 singers | 48.6 h | No | CC BY-NC-SA 4.0 |

## How to Download

The workbook lists the official source URL for every dataset. Summarised below:

| Dataset | Download URL |
|---|---|
| VOICED | https://physionet.org/content/voiced/1.0.0/ |
| SVD | https://stimmdb.coli.uni-saarland.de/ (mirror: https://zenodo.org/records/16874898) |
| VocalSet | https://zenodo.org/record/1442513 |
| NHSS | https://hltnus.github.io/NHSSDatabase/ |
| OpenSinger | https://github.com/Multi-Singer/Multi-Singer.github.io |

After downloading, follow the file-structure sheets to verify that the
local layout matches the expected directory tree before running the
PhysioVox training pipeline.

## Recommended Directory Layout

```
~/PhysioVox_data/
├── VOICED/voiced-1.0.0/
├── SVD/
├── VocalSet/VocalSet1-2/
├── NHSS/NHSS_Database/
└── OpenSinger/
```

Point the corresponding command-line flags of the PhysioVox training and
evaluation scripts to these paths.

## License Notice

The metadata workbook itself is released under the same license as the
PhysioVox project. The underlying datasets are distributed by their
respective providers under the licenses listed above; please consult
each dataset's official documentation before redistribution.
