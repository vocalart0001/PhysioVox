"""
PhysioVox loss functions.

Combines the four loss components defined in Equation (14) of the manuscript:

    L_total = L_cls + lambda_phys * L_phys + lambda_caus * L_caus + lambda_reg * L_reg
"""

from typing import Any, Dict, Optional

import torch
import torch.nn as nn

from .causal import CausalConsistencyLoss, VOCALSET_TECHNIQUES, technique_index
from .classification import ClassificationLoss
from .physical import EGGReconstructionLoss, MultiScaleSpectralLoss
from .regularization import DisentanglementRegularization

__all__ = [
    "ClassificationLoss",
    "EGGReconstructionLoss",
    "MultiScaleSpectralLoss",
    "CausalConsistencyLoss",
    "DisentanglementRegularization",
    "PhysioVoxLoss",
    "VOCALSET_TECHNIQUES",
    "technique_index",
]


class PhysioVoxLoss(nn.Module):
    """Composite loss implementing Equation (14)."""

    def __init__(self, config: Dict[str, Any], stage: str = "finetune") -> None:
        super().__init__()
        self.stage = stage
        loss_cfg = config["losses"]

        self.classification = ClassificationLoss(
            label_smoothing=loss_cfg["classification"]["label_smoothing"]
        )
        self.physical = EGGReconstructionLoss(
            spectral_weight=loss_cfg["physical"]["spectral_weight"],
            n_fft_scales=loss_cfg["physical"]["n_fft_scales"],
        )
        self.causal = CausalConsistencyLoss(
            vibrato_band=tuple(loss_cfg["causal"]["vibrato_band"]),
            breathy_threshold=loss_cfg["causal"]["breathy_threshold"],
            jitter_threshold=loss_cfg["causal"]["jitter_threshold"],
            f1_belt_threshold=loss_cfg["causal"]["f1_belt_threshold"],
            frame_rate_hz=1000.0 / config["audio"]["hop_length_ms"],
        )
        self.regularization = DisentanglementRegularization(
            gamma_spectral=loss_cfg["regularization"]["gamma_spectral"],
            gamma_mutual_info=loss_cfg["regularization"]["gamma_mutual_info"],
        )

        # Dynamic loss weight schedule (Section 3.4 of the manuscript):
        # the pretraining phase emphasises physical supervision; the
        # transfer (fine-tuning) phase raises the causal weight.
        if stage == "pretrain":
            self.lambda_cls = loss_cfg["classification"]["weight"]
            self.lambda_phys = loss_cfg["physical"]["weight_pretrain"]
            self.lambda_caus = loss_cfg["causal"]["weight_pretrain"]
            self.lambda_reg = loss_cfg["regularization"]["weight"]
        else:
            self.lambda_cls = loss_cfg["classification"]["weight"]
            self.lambda_phys = loss_cfg["physical"]["weight_finetune"]
            self.lambda_caus = loss_cfg["causal"]["weight_finetune"]
            self.lambda_reg = loss_cfg["regularization"]["weight"]

    def forward(
        self,
        outputs: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            outputs: forward pass results from PhysioVoxModel.
            targets: dict containing optional 'label' and 'egg_signal'.

        Returns:
            Dictionary holding the total loss and each component.
        """
        components: Dict[str, torch.Tensor] = {}
        total = torch.zeros((), device=outputs["logits"].device)

        if "label" in targets and self.lambda_cls > 0.0:
            l_cls = self.classification(outputs["logits"], targets["label"])
            components["L_cls"] = l_cls.detach()
            total = total + self.lambda_cls * l_cls

        if "egg_signal" in targets and self.lambda_phys > 0.0:
            l_phys = self.physical(outputs["glottal_flow"], targets["egg_signal"])
            components["L_phys"] = l_phys.detach()
            total = total + self.lambda_phys * l_phys

        if "psi_frames" in outputs and self.lambda_caus > 0.0:
            l_caus = self.causal(
                logits=outputs["logits"],
                psi_dict=outputs["psi_dict"],
                psi_frames=outputs["psi_frames"],
                formants=outputs["formants"],
            )
            components["L_caus"] = l_caus.detach()
            total = total + self.lambda_caus * l_caus

        if self.lambda_reg > 0.0:
            # Spectral envelope of the glottal flow for the smoothness term.
            spec_envelope = torch.abs(
                torch.fft.rfft(outputs["glottal_flow"], dim=-1)
            )
            l_reg = self.regularization(
                spectral_envelope=spec_envelope,
                psi=outputs["psi"],
                phi=outputs["phi"],
            )
            components["L_reg"] = l_reg.detach()
            total = total + self.lambda_reg * l_reg

        components["L_total"] = total
        return components
