"""
Source-Filter Disentanglement Regularization.

Implements Equation (10) of the manuscript:

    L_reg = gamma_1 * || grad_f log G_theta(f) ||_2^2
            + gamma_2 * MI(psi, phi)

The first term constrains the glottal source spectrum to have a smooth
envelope (no sharp resonance peaks). The second term constrains the
source parameters psi and the filter parameters phi to be mutually
independent in representation space. The mutual-information term is
implemented with a neural mutual-information estimator (MINE) to maintain
end-to-end differentiability.
"""

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class SpectralSmoothnessLoss(nn.Module):
    """First term of Equation (10): smoothness penalty on log |G(f)|."""

    def __init__(self, eps: float = 1.0e-6) -> None:
        super().__init__()
        self.eps = eps

    def forward(self, spectral_envelope: torch.Tensor) -> torch.Tensor:
        # spectral_envelope: (B, F) magnitude spectrum.
        log_mag = torch.log(spectral_envelope + self.eps)
        # First-order finite difference along the frequency axis.
        diff = log_mag[..., 1:] - log_mag[..., :-1]
        return diff.pow(2).mean()


class MINEEstimator(nn.Module):
    """
    Mutual Information Neural Estimator (MINE).

    Estimates I(X, Y) using the Donsker-Varadhan dual representation:
        I(X, Y) >= sup_T E_p(x,y)[T(x, y)] - log E_p(x)p(y)[exp T(x, y)]
    """

    def __init__(
        self,
        dim_x: int,
        dim_y: int,
        hidden_dim: int = 128,
    ) -> None:
        super().__init__()
        self.statistics_network = nn.Sequential(
            nn.Linear(dim_x + dim_y, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        # Exponential moving average of the denominator term for stable gradients.
        self.register_buffer("ema_denom", torch.tensor(1.0))
        self.ema_decay = 0.99

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Returns a non-negative scalar approximating I(X, Y).
        """
        batch_size = x.shape[0]
        if batch_size < 2:
            return torch.zeros((), device=x.device)
        # Joint samples (x_i, y_i).
        joint = torch.cat([x, y], dim=-1)
        # Marginal samples (x_i, y_{perm(i)}).
        perm = torch.randperm(batch_size, device=x.device)
        marginal = torch.cat([x, y[perm]], dim=-1)

        t_joint = self.statistics_network(joint).squeeze(-1)
        t_marginal = self.statistics_network(marginal).squeeze(-1)

        # MINE lower bound on mutual information.
        # E_joint[T] - log( E_marginal[exp(T)] )
        first_term = t_joint.mean()
        second_term = torch.logsumexp(t_marginal, dim=0) - torch.log(
            torch.tensor(float(batch_size), device=x.device)
        )
        mi_lower_bound = first_term - second_term
        # Clamp to zero since I(X;Y) >= 0.
        return F.relu(mi_lower_bound)


class DisentanglementRegularization(nn.Module):
    """L_reg of Equation (10): spectral smoothness + MINE mutual information."""

    def __init__(
        self,
        gamma_spectral: float = 0.1,
        gamma_mutual_info: float = 0.05,
        dim_psi: int = 5,
        dim_phi: int = 16,
        mine_hidden: int = 128,
    ) -> None:
        super().__init__()
        self.gamma_spectral = gamma_spectral
        self.gamma_mutual_info = gamma_mutual_info
        self.spectral_smoothness = SpectralSmoothnessLoss()
        self.mine = MINEEstimator(dim_x=dim_psi, dim_y=dim_phi, hidden_dim=mine_hidden)

    def forward(
        self,
        spectral_envelope: torch.Tensor,
        psi: torch.Tensor,
        phi: torch.Tensor,
    ) -> torch.Tensor:
        l_smooth = self.spectral_smoothness(spectral_envelope)
        l_mi = self.mine(psi, phi)
        return self.gamma_spectral * l_smooth + self.gamma_mutual_info * l_mi
