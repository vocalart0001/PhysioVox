"""
Acoustic-Physiological Causal Consistency Loss.

Implements the causal-consistency loss L_caus introduced in Section 3.4 of
the manuscript. Mechanistic causal correspondences between technique
labels and physiological parameters are written into the objective:

    vibrato     -> 5-7 Hz periodic modulation of glottal oscillation (Eq. 11)
    breathy     -> incomplete glottal closure, CQ > 0.5         (Eq. 12)
    vocal fry   -> period jitter > 3%                            (Eq. 13)
    belt        -> high F1 formant resonance > 750 Hz            (Eq. 13)

The total causal loss aggregates all such "technique -> physiology" terms
weighted by the soft indicator function I_k(y) read from the classifier
output probabilities (Eq. 13).
"""

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


# Standard 17-class VocalSet technique ordering used throughout the project.
VOCALSET_TECHNIQUES = (
    "vibrato", "straight", "breathy", "vocal_fry", "lip_trill",
    "trill", "trillo", "inhaled", "belt", "messa_di_voce",
    "forte", "piano", "fast_forte", "slow_forte",
    "fast_piano", "slow_piano", "spoken",
)


def technique_index(name: str) -> int:
    return VOCALSET_TECHNIQUES.index(name)


class CausalConsistencyLoss(nn.Module):
    """
    Multi-term causal consistency loss aggregating four explicit
    technique-physiology correspondences described in Section 3.4.
    """

    def __init__(
        self,
        vibrato_band: tuple = (5.0, 7.0),
        breathy_threshold: float = 0.5,
        jitter_threshold: float = 0.03,
        f1_belt_threshold: float = 750.0,
        weights: Optional[Dict[str, float]] = None,
        frame_rate_hz: float = 100.0,
    ) -> None:
        super().__init__()
        self.vibrato_band = vibrato_band
        self.breathy_threshold = breathy_threshold
        self.jitter_threshold = jitter_threshold
        self.f1_belt_threshold = f1_belt_threshold
        self.frame_rate_hz = frame_rate_hz
        self.weights = weights or {
            "vibrato": 1.0,
            "breathy": 1.0,
            "vocal_fry": 1.0,
            "belt": 1.0,
        }

    @staticmethod
    def _soft_indicator(
        class_probabilities: torch.Tensor, technique: str
    ) -> torch.Tensor:
        """
        Soft indicator function I_k(y) defined in Equation (13).
        Returns the predicted probability mass on class k for each sample.
        """
        idx = technique_index(technique)
        return class_probabilities[..., idx]

    def _vibrato_modulation_depth(
        self, f0_frames: torch.Tensor
    ) -> torch.Tensor:
        """
        Operator M_{5-7}(F0_t) introduced in Equation (11).

        Computes the spectral magnitude of the F0 time series within the
        5-7 Hz band normalised by the F0 mean, yielding a per-utterance
        modulation depth in [0, 1].
        """
        # f0_frames: (B, T_frames)
        f0_mean = f0_frames.mean(dim=-1, keepdim=True).clamp(min=1.0)
        f0_centered = f0_frames - f0_mean
        # FFT of the centred F0 contour.
        spectrum = torch.fft.rfft(f0_centered, dim=-1)
        magnitude = torch.abs(spectrum)
        n_frames = f0_frames.shape[-1]
        freqs = torch.fft.rfftfreq(n_frames, d=1.0 / self.frame_rate_hz).to(f0_frames.device)
        band_mask = (freqs >= self.vibrato_band[0]) & (freqs <= self.vibrato_band[1])
        band_energy = magnitude[..., band_mask].sum(dim=-1)
        total_energy = magnitude.sum(dim=-1).clamp(min=1.0e-6)
        return band_energy / total_energy

    def _vibrato_term(
        self,
        class_probabilities: torch.Tensor,
        f0_frames: torch.Tensor,
    ) -> torch.Tensor:
        """Equation (11): L_vib = || I_vib(y) - M_{5-7}(F0_t) ||_1"""
        indicator = self._soft_indicator(class_probabilities, "vibrato")
        modulation = self._vibrato_modulation_depth(f0_frames)
        return F.l1_loss(indicator, modulation)

    def _breathy_term(
        self,
        class_probabilities: torch.Tensor,
        oq: torch.Tensor,
    ) -> torch.Tensor:
        """
        Equation (12): L_breath = ReLU( I_breath(y) * (CQ(psi) - 0.5) )

        Where CQ(psi) = 1 - Oq. The closed quotient of a sample classified
        as breathy must be below the breathy threshold (default 0.5).
        """
        indicator = self._soft_indicator(class_probabilities, "breathy")
        closed_quotient = 1.0 - oq
        violation = F.relu(indicator * (closed_quotient - self.breathy_threshold))
        return violation.mean()

    def _vocal_fry_term(
        self,
        class_probabilities: torch.Tensor,
        f0_frames: torch.Tensor,
    ) -> torch.Tensor:
        """
        Equation (13) instantiation for vocal fry: period jitter > 3%.

        Jitter is estimated from successive F0 frames as
            jitter = mean(|F0[t] - F0[t-1]|) / mean(F0)
        """
        indicator = self._soft_indicator(class_probabilities, "vocal_fry")
        f0_mean = f0_frames.mean(dim=-1).clamp(min=1.0)
        diffs = torch.abs(f0_frames[:, 1:] - f0_frames[:, :-1])
        jitter = diffs.mean(dim=-1) / f0_mean
        violation = F.relu(indicator * (self.jitter_threshold - jitter))
        return violation.mean()

    def _belt_term(
        self,
        class_probabilities: torch.Tensor,
        formants: torch.Tensor,
    ) -> torch.Tensor:
        """Belt technique: F1 (first formant) > 750 Hz."""
        indicator = self._soft_indicator(class_probabilities, "belt")
        f1 = formants[..., 0]
        # Normalise the F1 distance by the threshold so the gradient is well
        # scaled regardless of absolute Hz magnitude.
        deficit = F.relu(self.f1_belt_threshold - f1) / self.f1_belt_threshold
        violation = indicator * deficit
        return violation.mean()

    def forward(
        self,
        logits: torch.Tensor,
        psi_dict: Dict[str, torch.Tensor],
        psi_frames: torch.Tensor,
        formants: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            logits: (B, n_classes) classifier logits.
            psi_dict: utterance-level physiological parameters.
            psi_frames: (B, T_frames, 5) per-frame physiological parameters
                used for vibrato and jitter analysis.
            formants: (B, 4) formant frequencies in Hz.

        Returns:
            Scalar tensor holding the aggregated causal consistency loss.
        """
        probs = F.softmax(logits, dim=-1)
        # F0 contour from the per-frame physiological parameter estimate.
        # Channel 4 of psi_frames corresponds to F0 in the canonical order
        # [Oq, Sq, Na, Rd, F0].
        f0_frames = psi_frames[..., 4]

        l_vib = self.weights["vibrato"] * self._vibrato_term(probs, f0_frames)
        l_breath = self.weights["breathy"] * self._breathy_term(probs, psi_dict["Oq"])
        l_fry = self.weights["vocal_fry"] * self._vocal_fry_term(probs, f0_frames)
        l_belt = self.weights["belt"] * self._belt_term(probs, formants)

        return l_vib + l_breath + l_fry + l_belt
