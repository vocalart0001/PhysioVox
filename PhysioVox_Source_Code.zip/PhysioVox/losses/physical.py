"""
EGG-driven physical supervision loss.

Implements Equation (9) of the manuscript:

    L_phys = (1 / T) * sum_t || g_theta(t) - g_EGG(t) ||_2^2
             + beta * L_spec(g_theta, g_EGG)

The first term is a time-domain MSE between the LF-synthesised glottal
flow and the EGG ground truth. The second term is a multi-scale spectral
distance that compensates for the insensitivity of the pure time-domain
loss to high-frequency details.
"""

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiScaleSpectralLoss(nn.Module):
    """Multi-scale STFT magnitude loss in log domain."""

    def __init__(
        self,
        n_fft_scales: Sequence[int] = (256, 512, 1024, 2048),
        eps: float = 1.0e-8,
    ) -> None:
        super().__init__()
        self.n_fft_scales = list(n_fft_scales)
        self.eps = eps

    def _stft_magnitude(
        self, signal: torch.Tensor, n_fft: int
    ) -> torch.Tensor:
        window = torch.hann_window(n_fft, device=signal.device)
        stft = torch.stft(
            signal,
            n_fft=n_fft,
            hop_length=n_fft // 4,
            win_length=n_fft,
            window=window,
            return_complex=True,
            center=True,
        )
        return torch.abs(stft)

    def forward(
        self, prediction: torch.Tensor, target: torch.Tensor
    ) -> torch.Tensor:
        loss = 0.0
        for n_fft in self.n_fft_scales:
            pred_mag = self._stft_magnitude(prediction, n_fft)
            tgt_mag = self._stft_magnitude(target, n_fft)
            # L1 in magnitude domain + L1 in log-magnitude domain.
            mag_l1 = F.l1_loss(pred_mag, tgt_mag)
            log_l1 = F.l1_loss(
                torch.log(pred_mag + self.eps),
                torch.log(tgt_mag + self.eps),
            )
            loss = loss + mag_l1 + log_l1
        return loss / len(self.n_fft_scales)


class EGGReconstructionLoss(nn.Module):
    """
    L_phys (Equation 9 of the manuscript).

    Combines time-domain MSE with a multi-scale spectral distance. The
    weight beta is configurable; the default beta = 0.5 follows the
    pretraining schedule documented in Section 4.1.
    """

    def __init__(
        self,
        spectral_weight: float = 0.5,
        n_fft_scales: Sequence[int] = (256, 512, 1024, 2048),
    ) -> None:
        super().__init__()
        self.spectral_weight = spectral_weight
        self.spectral_loss = MultiScaleSpectralLoss(n_fft_scales=n_fft_scales)

    def forward(
        self, glottal_flow: torch.Tensor, egg_signal: torch.Tensor
    ) -> torch.Tensor:
        # Equation (9), first term: per-sample MSE.
        time_mse = F.mse_loss(glottal_flow, egg_signal)
        # Equation (9), second term: multi-scale spectral distance.
        spec_loss = self.spectral_loss(glottal_flow, egg_signal)
        return time_mse + self.spectral_weight * spec_loss
