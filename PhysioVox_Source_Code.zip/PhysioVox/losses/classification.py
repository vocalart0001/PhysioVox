"""
Classification loss for vocal technique recognition.

Implements the cross-entropy term L_cls in Equation (1) and Equation (14)
of the manuscript with optional label smoothing.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ClassificationLoss(nn.Module):
    """Cross-entropy with label smoothing for the 17-class technique task."""

    def __init__(self, label_smoothing: float = 0.1) -> None:
        super().__init__()
        self.label_smoothing = label_smoothing

    def forward(
        self, logits: torch.Tensor, target: torch.Tensor
    ) -> torch.Tensor:
        return F.cross_entropy(
            logits, target, label_smoothing=self.label_smoothing
        )
