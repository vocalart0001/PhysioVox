"""
Stage 2: VocalSet fine-tuning on top of the EGG-pretrained model.

Loads the pretrained checkpoint, transfers the encoder, source branch,
filter branch, and differentiable LF synthesizer weights, then optimises
the target-domain loss with the parameter-distance regularisation term
centred on theta_s* (Equation 2 of the manuscript).
"""

from pathlib import Path
from typing import Any, Dict, Optional

import torch

from data_processing import FeaturePipeline, VocalSetDataset, build_dataloader
from models import PhysioVoxModel
from .trainer import TwoStageTrainer


def run_finetune(
    config: Dict[str, Any],
    vocalset_root: str,
    pretrained_checkpoint: Optional[str] = None,
    fold_index: int = 0,
) -> Dict[str, Any]:
    feature_pipeline = FeaturePipeline(config)

    full_dataset = VocalSetDataset(
        root_dir=vocalset_root,
        target_sampling_rate=config["audio"]["sampling_rate"],
        segment_seconds=config["audio"]["segment_seconds"],
        feature_pipeline=feature_pipeline,
    )

    if len(full_dataset) == 0:
        raise FileNotFoundError(
            f"No VocalSet WAV files were found under '{vocalset_root}'. "
            "Please download VocalSet (Zenodo DOI 10.5281/zenodo.1442513) before fine-tuning."
        )

    # 5-fold cross-validation split by singer (Section 4.1).
    singers = sorted({item["singer"] for item in full_dataset.manifest})
    n_folds = config["data"]["cv_folds"]
    fold_size = max(1, len(singers) // n_folds)
    fold_singers = singers[fold_index * fold_size:(fold_index + 1) * fold_size]

    train_indices = [
        i for i, item in enumerate(full_dataset.manifest)
        if item["singer"] not in fold_singers
    ]
    val_indices = [
        i for i, item in enumerate(full_dataset.manifest)
        if item["singer"] in fold_singers
    ]

    train_subset = torch.utils.data.Subset(full_dataset, train_indices)
    val_subset = torch.utils.data.Subset(full_dataset, val_indices)

    train_loader = build_dataloader(
        train_subset,
        batch_size=config["training"]["finetune"]["batch_size"],
        num_workers=config["experiment"]["num_workers"],
        shuffle=True,
        drop_last=True,
    )
    val_loader = build_dataloader(
        val_subset,
        batch_size=config["training"]["finetune"]["batch_size"],
        num_workers=config["experiment"]["num_workers"],
        shuffle=False,
    )

    model = PhysioVoxModel(config)
    if pretrained_checkpoint and Path(pretrained_checkpoint).exists():
        transferred = model.load_pretrained_encoder(pretrained_checkpoint)
        print(f"[Fine-tune] Transferred {transferred} parameter tensors from {pretrained_checkpoint}")

    trainer = TwoStageTrainer(
        model=model,
        config=config,
        stage="finetune",
        log_dir=config["logging"]["output_dir"] + "/logs",
        checkpoint_dir=config["logging"]["output_dir"] + "/checkpoints",
    )
    trainer.snapshot_source_parameters()

    history = trainer.fit(train_loader, val_loader=val_loader)
    return {
        "history": history,
        "fold_index": fold_index,
        "fold_singers": fold_singers,
        "checkpoint": "finetune_best.pt",
    }
