"""
Two-stage training loop for PhysioVox.

Implements the optimisation schedule described in Equation (2) of the
manuscript: stage 1 minimises the source-domain total loss on (VOICED +
SVD) to obtain theta_s*; stage 2 continues to optimise the target-domain
loss with a parameter-distance regularisation term centred on theta_s*.
"""

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, Optional

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader

from losses import PhysioVoxLoss
from models import PhysioVoxModel


class TwoStageTrainer:
    """Implements the pretrain / fine-tune optimisation schedule."""

    def __init__(
        self,
        model: PhysioVoxModel,
        config: Dict[str, Any],
        stage: str = "pretrain",
        device: Optional[torch.device] = None,
        log_dir: str = "results/logs",
        checkpoint_dir: str = "results/checkpoints",
    ) -> None:
        self.model = model
        self.config = config
        self.stage = stage
        self.device = device or torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
        self.model.to(self.device)

        self.loss_fn = PhysioVoxLoss(config, stage=stage).to(self.device)

        stage_cfg = config["training"][stage]
        self.epochs = stage_cfg["epochs"]
        self.grad_clip = stage_cfg.get("grad_clip_norm", 1.0)
        self.log_interval = stage_cfg.get("log_interval", 50)
        self.save_interval = stage_cfg.get("save_interval", 5)

        self.optimizer = AdamW(
            self.model.parameters(),
            lr=stage_cfg["learning_rate"],
            weight_decay=stage_cfg["weight_decay"],
        )

        self.log_dir = Path(log_dir)
        self.checkpoint_dir = Path(checkpoint_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.history = {"loss": [], "components": []}
        self.best_metric = math.inf

        # Snapshot of theta_s* for the parameter-distance regularisation in Eq. 2.
        self.source_params_snapshot: Optional[Dict[str, torch.Tensor]] = None
        self.transfer_alpha = (
            config["training"].get("finetune", {}).get("transfer_alpha", 0.1)
        )

    def snapshot_source_parameters(self) -> None:
        """Stores theta_s* for the parameter-distance regularisation."""
        self.source_params_snapshot = {
            name: param.detach().clone()
            for name, param in self.model.named_parameters()
        }

    def _parameter_distance(self) -> torch.Tensor:
        if self.source_params_snapshot is None:
            return torch.zeros((), device=self.device)
        dist = 0.0
        for name, param in self.model.named_parameters():
            if name in self.source_params_snapshot:
                dist = dist + (
                    (param - self.source_params_snapshot[name]).pow(2).mean()
                )
        return dist

    def _move_batch(self, batch: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for key, value in batch.items():
            if isinstance(value, torch.Tensor):
                out[key] = value.to(self.device, non_blocking=True)
            else:
                out[key] = value
        return out

    def _run_step(self, batch: Dict[str, Any]) -> Dict[str, float]:
        self.model.train()
        batch = self._move_batch(batch)

        if "mel" not in batch:
            raise KeyError("Expected pre-computed 'mel' in batch")
        outputs = self.model(batch["mel"])

        targets: Dict[str, torch.Tensor] = {}
        if "label" in batch:
            targets["label"] = batch["label"]
        if "egg_signal" in batch:
            # Trim/pad the EGG to match the synthesised glottal-flow length.
            target_len = outputs["glottal_flow"].shape[-1]
            egg = batch["egg_signal"]
            if egg.shape[-1] > target_len:
                egg = egg[..., :target_len]
            elif egg.shape[-1] < target_len:
                pad = target_len - egg.shape[-1]
                egg = torch.nn.functional.pad(egg, (0, pad))
            targets["egg_signal"] = egg

        components = self.loss_fn(outputs, targets)

        loss = components["L_total"]
        if self.stage == "finetune" and self.source_params_snapshot is not None:
            loss = loss + self.transfer_alpha * self._parameter_distance()

        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
        self.optimizer.step()

        report = {k: float(v.detach().cpu().item()) for k, v in components.items()}
        report["L_total"] = float(loss.detach().cpu().item())
        return report

    def fit(
        self,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
    ) -> Dict[str, Any]:
        steps_per_epoch = max(1, len(train_loader))
        scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=self.epochs * steps_per_epoch,
        )

        for epoch in range(1, self.epochs + 1):
            epoch_components: Dict[str, float] = {}
            for step, batch in enumerate(train_loader, start=1):
                report = self._run_step(batch)
                scheduler.step()
                for k, v in report.items():
                    epoch_components[k] = epoch_components.get(k, 0.0) + v

            for k in epoch_components:
                epoch_components[k] /= max(1, len(train_loader))
            self.history["loss"].append(epoch_components.get("L_total", 0.0))
            self.history["components"].append(epoch_components)

            log_path = self.log_dir / f"{self.stage}_epoch_log.json"
            with open(log_path, "w", encoding="utf-8") as fh:
                json.dump(self.history, fh, indent=2)

            if val_loader is not None:
                val_metric = self.evaluate(val_loader)
                if val_metric < self.best_metric:
                    self.best_metric = val_metric
                    self.save_checkpoint(name=f"{self.stage}_best.pt")

            if epoch % self.save_interval == 0:
                self.save_checkpoint(name=f"{self.stage}_epoch_{epoch}.pt")

        self.save_checkpoint(name=f"{self.stage}_final.pt")
        return self.history

    @torch.no_grad()
    def evaluate(self, val_loader: DataLoader) -> float:
        self.model.eval()
        total = 0.0
        count = 0
        for batch in val_loader:
            batch = self._move_batch(batch)
            outputs = self.model(batch["mel"])
            targets = {}
            if "label" in batch:
                targets["label"] = batch["label"]
            if "egg_signal" in batch:
                tgt_len = outputs["glottal_flow"].shape[-1]
                egg = batch["egg_signal"]
                if egg.shape[-1] != tgt_len:
                    egg = torch.nn.functional.pad(
                        egg[..., :tgt_len], (0, max(0, tgt_len - egg.shape[-1]))
                    )
                targets["egg_signal"] = egg
            components = self.loss_fn(outputs, targets)
            total += float(components["L_total"].cpu().item())
            count += 1
        return total / max(1, count)

    def save_checkpoint(self, name: str) -> str:
        path = self.checkpoint_dir / name
        torch.save({
            "model_state": self.model.state_dict(),
            "optimizer_state": self.optimizer.state_dict(),
            "config": self.config,
            "stage": self.stage,
            "history": self.history,
        }, path)
        return str(path)
