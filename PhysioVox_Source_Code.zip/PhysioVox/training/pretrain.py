"""
Stage 1: EGG-driven cross-domain pretraining.

Loads the clinical-domain VOICED and SVD datasets, builds the
PhysioVoxModel with the differentiable LF topology activated, and
optimises the source-domain total loss

    L_total^s = L_cls + lambda_phys * L_phys + lambda_caus * L_caus
              + lambda_reg * L_reg

to obtain theta_s* (Equation 2 of the manuscript).
"""

from pathlib import Path
from typing import Any, Dict

import torch
from torch.utils.data import ConcatDataset

from data_processing import (
    FeaturePipeline,
    SVDDataset,
    VOICEDDataset,
    build_dataloader,
)
from models import PhysioVoxModel
from .trainer import TwoStageTrainer


def run_pretrain(
    config: Dict[str, Any],
    voiced_root: str,
    svd_root: str,
) -> Dict[str, Any]:
    feature_pipeline = FeaturePipeline(config)

    datasets = []
    if voiced_root and Path(voiced_root).exists():
        datasets.append(VOICEDDataset(
            root_dir=voiced_root,
            target_sampling_rate=config["audio"]["sampling_rate"],
            segment_seconds=config["audio"]["segment_seconds"],
            feature_pipeline=feature_pipeline,
        ))
    if svd_root and Path(svd_root).exists():
        datasets.append(SVDDataset(
            root_dir=svd_root,
            target_sampling_rate=config["audio"]["sampling_rate"],
            segment_seconds=config["audio"]["segment_seconds"],
            feature_pipeline=feature_pipeline,
        ))

    if not datasets:
        raise FileNotFoundError(
            "Neither VOICED nor SVD root directories were found. "
            "Please download the clinical source-domain corpora before running pretraining."
        )

    combined = ConcatDataset(datasets)
    train_loader = build_dataloader(
        combined,
        batch_size=config["training"]["pretrain"]["batch_size"],
        num_workers=config["experiment"]["num_workers"],
        shuffle=True,
        drop_last=True,
    )

    model = PhysioVoxModel(config)
    trainer = TwoStageTrainer(
        model=model,
        config=config,
        stage="pretrain",
        log_dir=config["logging"]["output_dir"] + "/logs",
        checkpoint_dir=config["logging"]["output_dir"] + "/checkpoints",
    )

    history = trainer.fit(train_loader)
    trainer.save_checkpoint(name="pretrain_best.pt")
    return {"history": history, "checkpoint": "pretrain_best.pt"}
