"""
Supplementary visualisations.

Figure 6:  Main-results bar chart visualising Tables 3 and 4 of the
           manuscript (Accuracy + Macro-F1 across six methods and three
           datasets).
Figure 1:  PhysioVox architecture diagram visualising Section 3.1
           (Encoder + Source branch + Filter branch + LF synthesizer
            + Classifier head).
"""

import json
from pathlib import Path

import matplotlib.patches as patches
import matplotlib.pyplot as plt
import numpy as np


_METHOD_ORDER = [
    "MPS-SVM", "ResNet50-Mel", "CRNN",
    "HuBERT-Base-FT", "wav2vec2-LARGE-FT", "PhysioVox",
]
_METHOD_COLOURS = [
    "#8c8c8c", "#4c72b0", "#55a868", "#c44e52", "#8172b2", "#d62728",
]


def plot_figure_6(
    results_path: str = "results/tables/paper_results.json",
    output_path: str = "results/figures/Figure_6_main_results.png",
) -> str:
    """Bar-chart view of Tables 3 + 4 (main results across six methods)."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    main = results["main_results"]
    datasets = ["VocalSet", "NHSS", "OpenSinger"]

    fig, axes = plt.subplots(1, 2, figsize=(17, 6.5))

    for ax_idx, metric_name in enumerate(["accuracy", "macro_f1"]):
        ax = axes[ax_idx]
        x = np.arange(len(datasets))
        bar_width = 0.13
        for i, (method, colour) in enumerate(zip(_METHOD_ORDER, _METHOD_COLOURS)):
            values = [main[d][method][metric_name] for d in datasets]
            bars = ax.bar(
                x + (i - 2.5) * bar_width, values, bar_width,
                color=colour, alpha=0.95, edgecolor="black", linewidth=0.6,
                label=method,
            )
            for bar, value in zip(bars, values):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 0.008, f"{value:.3f}",
                    ha="center", va="bottom", fontsize=7.5,
                    fontweight="bold" if method == "PhysioVox" else "normal",
                )

        title = "Accuracy" if metric_name == "accuracy" else "Macro-F1"
        ax.set_title(f"({chr(ord('a') + ax_idx)}) {title}",
                     fontsize=12, fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels(datasets, fontsize=11, fontweight="bold")
        ax.set_ylabel(title, fontsize=11)
        ax.set_ylim(0.30, 0.92)
        ax.grid(axis="y", alpha=0.35, linestyle="--")
        ax.set_axisbelow(True)
        if ax_idx == 0:
            ax.legend(loc="upper right", fontsize=9, frameon=True, ncol=2)

    plt.suptitle(
        "Figure 6. Main results across three datasets (six-method comparison)",
        fontsize=13, fontweight="bold", y=1.02,
    )
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_figure_1(
    output_path: str = "results/figures/Figure_1_architecture.png",
) -> str:
    """Schematic of the PhysioVox architecture."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(15, 9))
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 10)
    ax.axis("off")

    def _box(x, y, w, h, label, fc, ec="black", fontsize=10):
        rect = patches.FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.08",
            facecolor=fc, edgecolor=ec, linewidth=1.5,
        )
        ax.add_patch(rect)
        ax.text(
            x + w / 2, y + h / 2, label,
            ha="center", va="center", fontsize=fontsize, fontweight="bold",
        )

    def _arrow(x1, y1, x2, y2, label="", color="black"):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=2.0))
        if label:
            ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.15, label,
                    ha="center", va="bottom", fontsize=8, style="italic")

    # Title.
    ax.text(7.5, 9.5, "Figure 1. PhysioVox architecture",
            ha="center", va="center", fontsize=14, fontweight="bold")

    # Input layer.
    _box(0.5, 7.0, 2.2, 1.0, "Waveform\n(16 kHz)", "#fff7e6")
    _box(0.5, 5.5, 2.2, 1.0, "Mel-Spectrogram\n80-d, 25/10 ms", "#fff7e6")

    # Encoder block.
    _box(3.5, 5.0, 3.5, 3.0,
         "Shared Transformer Encoder\n(6 layers, d=512, h=8)",
         "#e6f3ff")

    # Two branches.
    _box(8.0, 6.5, 3.0, 1.6,
         "Glottal Source Branch\n(5-D LF parameters)\nOq, Sq, Na, Rd, F0",
         "#ffe6e6")
    _box(8.0, 4.5, 3.0, 1.6,
         "Vocal-Tract Filter Branch\n(LPC order = 12)\n+ Formants (F1..F4)",
         "#e6ffe6")

    # Differentiable LF synthesizer.
    _box(12.0, 6.0, 2.8, 1.5,
         "Differentiable LF\nSynthesizer\n(Eqs. 3-6)",
         "#fde6ff")

    # Classifier.
    _box(12.0, 3.5, 2.8, 1.5,
         "Technique Classifier\n(17 classes)",
         "#fff0e6")

    # Loss bar (bottom).
    _box(3.5, 1.5, 8.0, 1.2,
         "Composite Loss (Eq. 14):  L_total = L_cls + λ_phys L_phys "
         "+ λ_caus L_caus + λ_reg L_reg",
         "#f7f7f7", fontsize=10)

    # EGG supervision pathway.
    _box(0.3, 1.5, 2.8, 1.2,
         "EGG signal\n(VOICED + SVD)\n→ L_phys",
         "#e8f5e9", fontsize=9)

    # Arrows.
    _arrow(1.6, 7.0, 1.6, 6.5)              # Waveform -> Mel
    _arrow(2.7, 6.0, 3.5, 6.0, "")          # Mel -> Encoder
    _arrow(7.0, 6.6, 8.0, 7.3)              # Encoder -> source branch
    _arrow(7.0, 5.6, 8.0, 5.3)              # Encoder -> filter branch
    _arrow(11.0, 7.3, 12.0, 6.95)           # Source -> LF synth
    _arrow(11.0, 5.3, 12.0, 4.25)           # Filter -> classifier (filter pooled)
    _arrow(7.0, 5.3, 12.0, 4.0, "pooled latent")  # Encoder -> classifier
    _arrow(13.4, 6.0, 13.4, 5.0)            # LF -> classifier
    _arrow(1.7, 2.7, 5.0, 1.7, "ground truth")  # EGG -> loss
    _arrow(13.4, 5.0, 11.5, 2.7)            # Classifier -> loss

    # Annotations.
    ax.text(
        0.5, 0.5,
        "Stage 1 (pretrain): EGG-driven cross-domain pretraining on VOICED + SVD\n"
        "Stage 2 (finetune): VocalSet fine-tuning with parameter-distance regularisation",
        fontsize=10, style="italic", color="#444444",
    )

    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


if __name__ == "__main__":
    out6 = plot_figure_6()
    print(f"Figure 6 saved to: {out6}")
    out1 = plot_figure_1()
    print(f"Figure 1 saved to: {out1}")
