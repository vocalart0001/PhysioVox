"""
Figure 10: Ablation contribution decomposition.

Renders the six-variant ablation chart (Table 5 of the manuscript) with
explicit Delta-Acc annotations relative to the Full PhysioVox model.
"""

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# Display order mirroring Table 5 / Figure 10 of the manuscript.
_VARIANT_ORDER = [
    "Full",
    "w/o Differentiable LF",
    "w/o EGG Pretraining",
    "w/o Causal Loss",
    "w/o Decoupling Regularization",
    "Backbone Only",
]

_VARIANT_COLOURS = [
    "#d62728",  # Full (highlight red)
    "#1f77b4",
    "#2ca02c",
    "#ff7f0e",
    "#9467bd",
    "#8c8c8c",
]


def plot_figure_10(
    results_path: str = "results/tables/paper_results.json",
    output_path: str = "results/figures/Figure_10_ablation_bars.png",
) -> str:
    """Renders Figure 10."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    ablation = results["ablation_results"]
    variants = _VARIANT_ORDER
    accuracies = [ablation[v]["accuracy"] for v in variants]
    macro_f1s = [ablation[v]["macro_f1"] for v in variants]
    deltas = [ablation[v]["delta_acc"] for v in variants]

    fig, ax = plt.subplots(figsize=(13, 7.5))
    x_positions = np.arange(len(variants))
    bar_width = 0.36

    bars_acc = ax.bar(
        x_positions - bar_width / 2, accuracies, width=bar_width,
        color=_VARIANT_COLOURS, alpha=0.95, edgecolor="black", linewidth=0.8,
        label="Accuracy",
    )
    bars_f1 = ax.bar(
        x_positions + bar_width / 2, macro_f1s, width=bar_width,
        color=_VARIANT_COLOURS, alpha=0.60, edgecolor="black", linewidth=0.8,
        hatch="//", label="Macro-F1",
    )

    # Annotate accuracy values and the Delta-Acc difference at the top.
    for i, (bar_a, bar_f, acc, f1, delta) in enumerate(
        zip(bars_acc, bars_f1, accuracies, macro_f1s, deltas)
    ):
        ax.text(
            bar_a.get_x() + bar_a.get_width() / 2,
            acc + 0.012,
            f"{acc:.3f}",
            ha="center", va="bottom", fontsize=9, fontweight="bold",
        )
        ax.text(
            bar_f.get_x() + bar_f.get_width() / 2,
            f1 + 0.012,
            f"{f1:.3f}",
            ha="center", va="bottom", fontsize=8,
        )
        if delta != 0:
            ax.text(
                x_positions[i], 0.93,
                f"ΔAcc = {delta:+.3f}",
                ha="center", va="center", fontsize=10, color="darkred", fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.3", fc="#ffe6e6", ec="darkred", linewidth=0.8),
            )

    ax.set_xticks(x_positions)
    ax.set_xticklabels(variants, rotation=20, ha="right", fontsize=10)
    ax.set_ylabel("Performance score", fontsize=11, fontweight="bold")
    ax.set_ylim(0.70, 0.98)
    ax.set_yticks([0.72, 0.76, 0.80, 0.84, 0.88, 0.92, 0.96])
    ax.set_title(
        "Figure 10. Module ablation contributions on VocalSet 17-class task",
        fontsize=12, fontweight="bold", pad=14,
    )
    ax.grid(axis="y", alpha=0.35, linestyle="--")
    ax.set_axisbelow(True)
    ax.legend(loc="lower right", fontsize=10, frameon=True)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


if __name__ == "__main__":
    out = plot_figure_10()
    print(f"Figure 10 saved to: {out}")
