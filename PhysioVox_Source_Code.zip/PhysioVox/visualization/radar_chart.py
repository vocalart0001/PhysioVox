"""
Radar visualisations.

Figure 9:  Cross-dataset macro-F1 comparison for six methods (PhysioVox +
           five baselines) on three datasets (VocalSet, NHSS, OpenSinger).
Figure 12: Five-dimensional physiological parameter profiles for the three
           pedagogical case studies discussed in Section 4.5.
"""

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# Distinct colour scheme that keeps PhysioVox visually dominant.
_METHOD_COLOURS = {
    "MPS-SVM":           "#8c8c8c",
    "ResNet50-Mel":      "#4c72b0",
    "CRNN":              "#55a868",
    "HuBERT-Base-FT":    "#c44e52",
    "wav2vec2-LARGE-FT": "#8172b2",
    "PhysioVox":         "#d62728",
}


def _radar_axis(ax, n_axes: int):
    """Configures a polar axis with n_axes equally-spaced category lines."""
    angles = np.linspace(0, 2 * np.pi, n_axes, endpoint=False).tolist()
    angles += angles[:1]
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    return angles


def plot_figure_9(
    results_path: str = "results/tables/paper_results.json",
    output_path: str = "results/figures/Figure_9_cross_dataset_radar.png",
) -> str:
    """Figure 9: cross-dataset radar of macro-F1 for six methods."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    main = results["main_results"]
    datasets = ["VocalSet", "NHSS", "OpenSinger"]
    methods = ["MPS-SVM", "ResNet50-Mel", "CRNN", "HuBERT-Base-FT",
               "wav2vec2-LARGE-FT", "PhysioVox"]

    fig, ax = plt.subplots(figsize=(9, 8), subplot_kw=dict(polar=True))
    angles = _radar_axis(ax, len(datasets))

    for method in methods:
        values = [main[d][method]["macro_f1"] for d in datasets]
        values_closed = values + values[:1]
        lw = 2.6 if method == "PhysioVox" else 1.4
        alpha_line = 1.0 if method == "PhysioVox" else 0.85
        alpha_fill = 0.20 if method == "PhysioVox" else 0.05
        ax.plot(
            angles, values_closed,
            label=method, color=_METHOD_COLOURS[method],
            linewidth=lw, alpha=alpha_line, marker="o", markersize=5,
        )
        ax.fill(angles, values_closed, color=_METHOD_COLOURS[method], alpha=alpha_fill)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(datasets, fontsize=12, fontweight="bold")
    ax.set_ylim(0.35, 0.90)
    ax.set_yticks([0.40, 0.50, 0.60, 0.70, 0.80])
    ax.set_yticklabels(["0.40", "0.50", "0.60", "0.70", "0.80"], fontsize=9)
    ax.set_rlabel_position(180.0 / len(datasets))
    ax.grid(alpha=0.4)
    ax.set_title(
        "Figure 9. Cross-dataset Macro-F1 comparison (PhysioVox vs five baselines)",
        fontsize=12, fontweight="bold", pad=20,
    )
    ax.legend(loc="lower left", bbox_to_anchor=(1.05, 0.0), fontsize=10, frameon=True)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_figure_12(
    results_path: str = "results/tables/paper_results.json",
    output_path: str = "results/figures/Figure_12_pedagogical_radar.png",
) -> str:
    """Figure 12: 5-D physiological radar for the three pedagogical cases."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    cases = results["pedagogical_cases"]

    # Axis order anchored to Section 3.4 (Oq, Sq, Na, Rd, F0).
    axis_names = ["Oq", "Sq", "Na", "Rd", "F0"]

    # Normaliser for each axis (Table 1 physiological bounds).
    bounds = {
        "Oq": (0.30, 0.90),
        "Sq": (1.00, 5.00),
        "Na": (0.05, 0.30),
        "Rd": (0.01, 0.30),
        "F0": (80.0, 1000.0),
    }

    def normalise(name, value):
        lo, hi = bounds[name]
        return (value - lo) / (hi - lo)

    fig, axes = plt.subplots(
        1, 3, figsize=(16, 6), subplot_kw=dict(polar=True),
    )

    colour_map = {
        "Case A": "#d62728",  # vibrato (red)
        "Case B": "#1f77b4",  # breathy (blue)
        "Case C": "#2ca02c",  # vocal fry (green)
    }

    for ax, case in zip(axes, cases):
        angles = _radar_axis(ax, len(axis_names))
        values = [normalise(name, case["psi"][name]) for name in axis_names]
        values_closed = values + values[:1]
        case_color = colour_map.get(case["case_id"], "#d62728")
        ax.plot(angles, values_closed, color=case_color, linewidth=2.5, marker="o", markersize=7)
        ax.fill(angles, values_closed, color=case_color, alpha=0.30)

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(axis_names, fontsize=11, fontweight="bold")
        ax.set_ylim(0.0, 1.0)
        ax.set_yticks([0.2, 0.4, 0.6, 0.8])
        ax.set_yticklabels(["0.2", "0.4", "0.6", "0.8"], fontsize=8)
        ax.set_rlabel_position(180.0 / len(axis_names))
        ax.grid(alpha=0.4)
        ax.set_title(
            f"{case['case_id']}: {case['label']}",
            fontsize=11, fontweight="bold", pad=20,
        )

        # Annotate the raw physiological values inside the polar plot.
        psi_text = "\n".join([
            f"Oq = {case['psi']['Oq']:.2f}",
            f"Sq = {case['psi']['Sq']:.2f}",
            f"Na = {case['psi']['Na']:.2f}",
            f"Rd = {case['psi']['Rd']:.2f}",
            f"F0 = {case['psi']['F0']:.0f} Hz",
        ])
        ax.text(
            -0.18, -0.18, psi_text, transform=ax.transAxes,
            fontsize=9, va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="gray", alpha=0.9),
        )

    plt.suptitle(
        "Figure 12. Five-dimensional physiological profiles for three pedagogical cases",
        fontsize=13, fontweight="bold", y=1.02,
    )
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


if __name__ == "__main__":
    out9 = plot_figure_9()
    print(f"Figure 9 saved to: {out9}")
    out12 = plot_figure_12()
    print(f"Figure 12 saved to: {out12}")
