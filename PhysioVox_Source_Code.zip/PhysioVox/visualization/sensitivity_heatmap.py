"""
Figure 11: Loss-weight sensitivity heatmap.

Visualises Macro-F1 over a bivariate sweep on (lambda_phys, lambda_caus)
showing the plateau where PhysioVox maintains high accuracy and the
optimal operating point at (lambda_phys = 1.0, lambda_caus = 0.5).
"""

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def plot_figure_11(
    results_path: str = "results/tables/paper_results.json",
    output_path: str = "results/figures/Figure_11_sensitivity_heatmap.png",
) -> str:
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    grid = results["sensitivity_grid"]
    lambda_phys = np.array(grid["lambda_phys_values"])
    lambda_caus = np.array(grid["lambda_caus_values"])
    matrix = np.array(grid["macro_f1_matrix"])
    optimal = grid["optimal_point"]

    fig, ax = plt.subplots(figsize=(11, 8))
    im = ax.imshow(
        matrix, cmap="RdYlBu_r", aspect="auto", origin="lower",
        vmin=0.72, vmax=0.85,
    )

    ax.set_xticks(range(len(lambda_caus)))
    ax.set_xticklabels([f"{x:.1f}" for x in lambda_caus], fontsize=10)
    ax.set_yticks(range(len(lambda_phys)))
    ax.set_yticklabels([f"{x:.1f}" for x in lambda_phys], fontsize=10)
    ax.set_xlabel(r"$\lambda_{caus}$ (causal-consistency weight)",
                  fontsize=12, fontweight="bold")
    ax.set_ylabel(r"$\lambda_{phys}$ (physical-supervision weight)",
                  fontsize=12, fontweight="bold")
    ax.set_title(
        "Figure 11. Loss-weight sensitivity (Macro-F1 surface on VocalSet)",
        fontsize=12, fontweight="bold", pad=12,
    )

    # Numerical annotations on every grid point.
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            v = matrix[i, j]
            color = "white" if v < 0.78 else "black"
            ax.text(
                j, i, f"{v:.3f}",
                ha="center", va="center", fontsize=7.5, color=color,
            )

    # Mark the optimal operating point with a star.
    opt_x = list(lambda_caus).index(optimal["lambda_caus"])
    opt_y = list(lambda_phys).index(optimal["lambda_phys"])
    ax.plot(
        opt_x, opt_y, marker="*", markersize=28, color="gold",
        markeredgecolor="black", markeredgewidth=1.8, zorder=5,
    )
    ax.annotate(
        f"Optimal point\n($\\lambda_{{phys}}$={optimal['lambda_phys']},"
        f" $\\lambda_{{caus}}$={optimal['lambda_caus']})\nMacro-F1 = {optimal['macro_f1']:.3f}",
        xy=(opt_x, opt_y), xytext=(opt_x + 1.6, opt_y + 1.4),
        fontsize=10, color="black", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.4", fc="lightyellow", ec="black", linewidth=1.0),
        arrowprops=dict(arrowstyle="->", color="black", linewidth=1.4),
    )

    # Contour around the high-performance plateau.
    contour_levels = [0.80, 0.82]
    cs = ax.contour(
        matrix, levels=contour_levels, colors="black",
        linewidths=1.2, linestyles="--",
    )
    ax.clabel(cs, fmt="%.2f", fontsize=8, inline=True)

    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Macro-F1", fontsize=11, fontweight="bold")

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


if __name__ == "__main__":
    out = plot_figure_11()
    print(f"Figure 11 saved to: {out}")
