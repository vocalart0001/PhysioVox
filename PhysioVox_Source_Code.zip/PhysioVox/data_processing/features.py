"""
Acoustic feature extraction.

Implements:
    - 80-dimensional Mel-spectrogram with 25 ms window and 10 ms hop
      (Section 4.1 of the manuscript).
    - LPC-12 formant extraction (Figure 1).
    - Optional EGG signal pre-processing for clinical-domain pretraining.
"""

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torchaudio.transforms as T


class MelSpectrogramExtractor(nn.Module):
    """80-mel spectrogram extractor matching the configuration in Section 4.1."""

    def __init__(
        self,
        sampling_rate: int = 16000,
        n_mels: int = 80,
        win_length_ms: float = 25.0,
        hop_length_ms: float = 10.0,
        f_min: float = 50.0,
        f_max: Optional[float] = None,
        n_fft: int = 400,
    ) -> None:
        super().__init__()
        self.sampling_rate = sampling_rate
        self.win_length = int(sampling_rate * win_length_ms / 1000.0)
        self.hop_length = int(sampling_rate * hop_length_ms / 1000.0)
        self.n_fft = max(n_fft, self.win_length)

        if f_max is None:
            f_max = sampling_rate / 2.0

        self.mel_transform = T.MelSpectrogram(
            sample_rate=sampling_rate,
            n_fft=self.n_fft,
            win_length=self.win_length,
            hop_length=self.hop_length,
            f_min=f_min,
            f_max=f_max,
            n_mels=n_mels,
            power=2.0,
            center=True,
        )
        self.amplitude_to_db = T.AmplitudeToDB(stype="power", top_db=80.0)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Args:
            waveform: (B, N) or (N,) audio tensor.
        Returns:
            (B, T_frames, n_mels) Mel spectrogram in dB.
        """
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        mel = self.mel_transform(waveform)  # (B, n_mels, T)
        mel_db = self.amplitude_to_db(mel)
        # Standard mean-variance normalisation per utterance.
        mean = mel_db.mean(dim=(-2, -1), keepdim=True)
        std = mel_db.std(dim=(-2, -1), keepdim=True).clamp(min=1.0e-5)
        mel_db = (mel_db - mean) / std
        return mel_db.transpose(-1, -2)  # (B, T, n_mels)


class LPCExtractor:
    """Linear predictive coding analysis (Burg algorithm)."""

    def __init__(self, order: int = 12) -> None:
        self.order = order

    def __call__(self, waveform: np.ndarray) -> np.ndarray:
        """
        Args:
            waveform: (N,) numpy array.
        Returns:
            (order,) LPC coefficients a_1, ..., a_p.
        """
        x = waveform.astype(np.float64)
        x = x - x.mean()
        n = len(x)
        p = self.order

        f = x.copy()
        b = x.copy()
        a = np.zeros(p + 1)
        a[0] = 1.0
        den = (f ** 2).sum() * 2.0

        for k in range(p):
            num = -2.0 * (f[k + 1:] * b[: n - k - 1]).sum()
            mu = num / max(den, 1.0e-12)
            new_a = a.copy()
            for j in range(k + 2):
                new_a[j] = a[j] + mu * a[k + 1 - j] if k + 1 - j >= 0 else a[j]
            a = new_a
            f_old = f[k + 1:].copy()
            b_old = b[: n - k - 1].copy()
            f = f_old + mu * b_old
            b = b_old + mu * f_old
            den = (1.0 - mu * mu) * den - f[0] ** 2 - b[-1] ** 2
        return a[1:]


class FeaturePipeline:
    """Convenience wrapper combining waveform loading and feature extraction."""

    def __init__(self, config: dict) -> None:
        self.sampling_rate = config["audio"]["sampling_rate"]
        self.mel_extractor = MelSpectrogramExtractor(
            sampling_rate=self.sampling_rate,
            n_mels=config["audio"]["n_mels"],
            win_length_ms=config["audio"]["win_length_ms"],
            hop_length_ms=config["audio"]["hop_length_ms"],
            n_fft=config["audio"]["n_fft"],
        )
        self.lpc_extractor = LPCExtractor(
            order=config["model"]["filter_branch"]["lpc_order"]
        )

    def extract_mel(self, waveform: torch.Tensor) -> torch.Tensor:
        return self.mel_extractor(waveform)

    def extract_lpc(self, waveform: np.ndarray) -> np.ndarray:
        return self.lpc_extractor(waveform)


def preprocess_egg(
    egg_signal: torch.Tensor,
    sampling_rate: int = 16000,
) -> torch.Tensor:
    """
    Differentiates the EGG signal to obtain the DEGG (derivative of EGG)
    waveform that is conventionally compared with the LF glottal flow.
    """
    if egg_signal.ndim == 1:
        egg_signal = egg_signal.unsqueeze(0)
    # Time-domain centred difference.
    diff = torch.zeros_like(egg_signal)
    diff[:, 1:-1] = (egg_signal[:, 2:] - egg_signal[:, :-2]) * (sampling_rate / 2.0)
    # Normalise to unit peak so that the EGG comparison is amplitude invariant.
    peak = diff.abs().max(dim=-1, keepdim=True).values.clamp(min=1.0e-6)
    return diff / peak
