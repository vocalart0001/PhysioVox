"""Data processing pipelines and dataset loaders."""

from .dataset import (
    CROSSDOMAIN_LABEL_MAP,
    AudioSample,
    NHSSDataset,
    OpenSingerDataset,
    SVDDataset,
    VOICEDDataset,
    VocalSetDataset,
    build_dataloader,
)
from .features import (
    FeaturePipeline,
    LPCExtractor,
    MelSpectrogramExtractor,
    preprocess_egg,
)

__all__ = [
    "AudioSample",
    "VOICEDDataset",
    "SVDDataset",
    "VocalSetDataset",
    "NHSSDataset",
    "OpenSingerDataset",
    "build_dataloader",
    "CROSSDOMAIN_LABEL_MAP",
    "FeaturePipeline",
    "LPCExtractor",
    "MelSpectrogramExtractor",
    "preprocess_egg",
]
