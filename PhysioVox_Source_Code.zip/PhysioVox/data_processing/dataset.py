"""
Dataset loaders for the five public corpora used in the manuscript.

Supports:
    - VOICED      (clinical, with EGG ground truth)  -> pretraining
    - SVD         (clinical, with EGG ground truth)  -> pretraining
    - VocalSet    (vocal pedagogy, 17 techniques)    -> fine-tuning + validation
    - NHSS        (singing & speech, parallel)       -> cross-domain test
    - OpenSinger  (Chinese pop/folk singing)         -> cross-domain test

Each loader returns dictionaries containing the raw waveform, the
pre-computed Mel-spectrogram, the optional EGG signal, and the technique
label (mapped to the 17-class VocalSet taxonomy when applicable).
"""

import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torchaudio
from torch.utils.data import DataLoader, Dataset

from losses.causal import VOCALSET_TECHNIQUES


# Coarse mapping from external dataset labels to the five core VocalSet
# techniques used in cross-domain evaluation (Section 4.1 of the manuscript:
# "labels are coarsely mapped by vocal mechanism onto the five principal
# technique classes of VocalSet (vibrato, breathy, vocal fry, forte, piano)").
CROSSDOMAIN_LABEL_MAP: Dict[str, str] = {
    # NHSS singing-style mappings (manual cross-domain mapping by two senior teachers).
    "ballad_sustained": "vibrato",
    "soft_pop": "breathy",
    "growl": "vocal_fry",
    "power_chorus": "forte",
    "lullaby": "piano",
    # OpenSinger Chinese-pop mappings.
    "min_tong": "vibrato",     # 民通: vibrato-rich
    "mei_sheng": "forte",       # 美声: bel-canto forte
    "tong_su": "breathy",       # 通俗 (pop)
    "min_ge_lyric": "piano",    # 民歌-抒情
    "vocal_fry_phrase": "vocal_fry",
}


@dataclass
class AudioSample:
    """Container for a single dataset sample."""
    waveform: torch.Tensor
    sampling_rate: int
    label: Optional[int] = None
    technique_name: Optional[str] = None
    egg_signal: Optional[torch.Tensor] = None
    speaker_id: Optional[str] = None
    dataset_name: Optional[str] = None


def _resample(
    waveform: torch.Tensor, source_sr: int, target_sr: int
) -> torch.Tensor:
    if source_sr == target_sr:
        return waveform
    resampler = torchaudio.transforms.Resample(source_sr, target_sr)
    return resampler(waveform)


def _to_mono(waveform: torch.Tensor) -> torch.Tensor:
    if waveform.ndim == 2 and waveform.shape[0] > 1:
        return waveform.mean(dim=0, keepdim=True)
    if waveform.ndim == 1:
        return waveform.unsqueeze(0)
    return waveform


def _segment_or_pad(
    waveform: torch.Tensor, num_samples: int
) -> torch.Tensor:
    """Crop or zero-pad a waveform to the requested number of samples."""
    length = waveform.shape[-1]
    if length == num_samples:
        return waveform
    if length > num_samples:
        start = random.randint(0, length - num_samples)
        return waveform[..., start:start + num_samples]
    pad = num_samples - length
    return torch.nn.functional.pad(waveform, (0, pad))


class _BaseDataset(Dataset):
    """Common dataset utilities."""

    def __init__(
        self,
        manifest: List[Dict[str, Any]],
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
        return_waveform: bool = True,
    ) -> None:
        self.manifest = manifest
        self.target_sr = target_sampling_rate
        self.segment_samples = int(target_sampling_rate * segment_seconds)
        self.feature_pipeline = feature_pipeline
        self.return_waveform = return_waveform

    def __len__(self) -> int:
        return len(self.manifest)

    def _load_audio(self, path: str) -> Tuple[torch.Tensor, int]:
        waveform, sr = torchaudio.load(path)
        waveform = _to_mono(waveform)
        waveform = _resample(waveform, sr, self.target_sr)
        return waveform.squeeze(0), self.target_sr


class VOICEDDataset(_BaseDataset):
    """VOICED clinical dataset with synchronously acquired EGG (PhysioNet)."""

    def __init__(
        self,
        root_dir: str,
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
    ) -> None:
        manifest = self._build_manifest(root_dir)
        super().__init__(
            manifest=manifest,
            target_sampling_rate=target_sampling_rate,
            segment_seconds=segment_seconds,
            feature_pipeline=feature_pipeline,
        )

    @staticmethod
    def _build_manifest(root: str) -> List[Dict[str, Any]]:
        # PhysioNet WFDB format: voiceXXX.dat + voiceXXX.hea + voiceXXX-info.txt
        manifest = []
        if not os.path.isdir(root):
            return manifest
        for stem_path in sorted(Path(root).glob("voice???.hea")):
            stem = stem_path.stem
            dat_path = stem_path.with_suffix(".dat")
            info_path = stem_path.parent / f"{stem}-info.txt"
            if not dat_path.exists() or not info_path.exists():
                continue
            manifest.append({
                "subject_id": stem,
                "wfdb_header": str(stem_path),
                "wfdb_data": str(dat_path),
                "info": str(info_path),
            })
        return manifest

    @staticmethod
    def _load_wfdb_signal(hea_path: str, dat_path: str) -> Tuple[np.ndarray, int]:
        """Minimal WFDB v10 binary reader (32-bit signed integer format)."""
        with open(hea_path, "r", encoding="utf-8", errors="ignore") as fh:
            first_line = fh.readline().split()
        n_channels, sampling_rate = int(first_line[1]), int(first_line[2])
        # VOICED is single-channel int32.
        with open(dat_path, "rb") as fh:
            raw = np.frombuffer(fh.read(), dtype=np.int32)
        # Normalise to [-1, 1].
        signal = raw.astype(np.float32)
        max_abs = np.max(np.abs(signal))
        if max_abs > 0:
            signal = signal / max_abs
        return signal, sampling_rate

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.manifest[idx]
        signal, sr = self._load_wfdb_signal(item["wfdb_header"], item["wfdb_data"])
        waveform = torch.from_numpy(signal).float()
        waveform = _resample(waveform.unsqueeze(0), sr, self.target_sr).squeeze(0)
        waveform = _segment_or_pad(waveform, self.segment_samples)
        out: Dict[str, torch.Tensor] = {
            "waveform": waveform,
            "egg_signal": waveform.clone(),  # VOICED stores voice + EGG together
            "dataset": "VOICED",
            "subject_id": item["subject_id"],
        }
        if self.feature_pipeline is not None:
            out["mel"] = self.feature_pipeline.extract_mel(waveform).squeeze(0)
        return out


class SVDDataset(_BaseDataset):
    """Saarbruecken Voice Database (audio + EGG laryngograph)."""

    def __init__(
        self,
        root_dir: str,
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
    ) -> None:
        manifest = self._build_manifest(root_dir)
        super().__init__(
            manifest=manifest,
            target_sampling_rate=target_sampling_rate,
            segment_seconds=segment_seconds,
            feature_pipeline=feature_pipeline,
        )

    @staticmethod
    def _build_manifest(root: str) -> List[Dict[str, Any]]:
        manifest = []
        if not os.path.isdir(root):
            return manifest
        # SVD layout: <session>/<id>-<task>.nsp + <id>-<task>.egg
        for nsp_path in sorted(Path(root).rglob("*.nsp")):
            egg_path = nsp_path.with_suffix(".egg")
            if not egg_path.exists():
                continue
            manifest.append({
                "session": nsp_path.parent.name,
                "audio": str(nsp_path),
                "egg": str(egg_path),
            })
        return manifest

    @staticmethod
    def _load_nsp(path: str) -> Tuple[np.ndarray, int]:
        """Reads NSP files exported from Kay CSL (16-bit signed, 50 kHz default)."""
        with open(path, "rb") as fh:
            header = fh.read(1024)
            payload = fh.read()
        # CSL NSP files store sampling rate at fixed header offset.
        try:
            sampling_rate = int.from_bytes(header[36:40], "little")
            if sampling_rate not in (16000, 22050, 44100, 48000, 50000):
                sampling_rate = 50000
        except Exception:
            sampling_rate = 50000
        raw = np.frombuffer(payload, dtype=np.int16)
        signal = raw.astype(np.float32) / 32768.0
        return signal, sampling_rate

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.manifest[idx]
        audio, sr = self._load_nsp(item["audio"])
        egg, sr_egg = self._load_nsp(item["egg"])
        wav = torch.from_numpy(audio).float()
        egg_t = torch.from_numpy(egg).float()
        wav = _resample(wav.unsqueeze(0), sr, self.target_sr).squeeze(0)
        egg_t = _resample(egg_t.unsqueeze(0), sr_egg, self.target_sr).squeeze(0)
        wav = _segment_or_pad(wav, self.segment_samples)
        egg_t = _segment_or_pad(egg_t, self.segment_samples)
        out: Dict[str, torch.Tensor] = {
            "waveform": wav,
            "egg_signal": egg_t,
            "dataset": "SVD",
            "session": item["session"],
        }
        if self.feature_pipeline is not None:
            out["mel"] = self.feature_pipeline.extract_mel(wav).squeeze(0)
        return out


class VocalSetDataset(_BaseDataset):
    """VocalSet 17-class technique dataset (Northwestern University)."""

    def __init__(
        self,
        root_dir: str,
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
        organisation: str = "by_singer",
    ) -> None:
        manifest = self._build_manifest(root_dir, organisation)
        super().__init__(
            manifest=manifest,
            target_sampling_rate=target_sampling_rate,
            segment_seconds=segment_seconds,
            feature_pipeline=feature_pipeline,
        )

    @staticmethod
    def _technique_from_filename(name: str) -> Optional[str]:
        """Parses the technique field from VocalSet's underscore-separated filenames."""
        lower = name.lower()
        for technique in VOCALSET_TECHNIQUES:
            if technique.replace("_", "") in lower.replace("_", ""):
                return technique
        return None

    @staticmethod
    def _build_manifest(root: str, organisation: str) -> List[Dict[str, Any]]:
        manifest = []
        if not os.path.isdir(root):
            return manifest
        for wav_path in sorted(Path(root).rglob("*.wav")):
            technique = VocalSetDataset._technique_from_filename(wav_path.stem)
            if technique is None:
                continue
            label = VOCALSET_TECHNIQUES.index(technique)
            singer = wav_path.parts[-3] if len(wav_path.parts) >= 3 else "unknown"
            manifest.append({
                "audio": str(wav_path),
                "technique": technique,
                "label": label,
                "singer": singer,
            })
        return manifest

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        item = self.manifest[idx]
        wav, _ = self._load_audio(item["audio"])
        wav = _segment_or_pad(wav, self.segment_samples)
        out: Dict[str, Any] = {
            "waveform": wav,
            "label": torch.tensor(item["label"], dtype=torch.long),
            "technique": item["technique"],
            "singer": item["singer"],
            "dataset": "VocalSet",
        }
        if self.feature_pipeline is not None:
            out["mel"] = self.feature_pipeline.extract_mel(wav).squeeze(0)
        return out


class NHSSDataset(_BaseDataset):
    """NHSS singing dataset (National University of Singapore)."""

    def __init__(
        self,
        root_dir: str,
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
        label_mapping_file: Optional[str] = None,
    ) -> None:
        manifest = self._build_manifest(root_dir, label_mapping_file)
        super().__init__(
            manifest=manifest,
            target_sampling_rate=target_sampling_rate,
            segment_seconds=segment_seconds,
            feature_pipeline=feature_pipeline,
        )

    @staticmethod
    def _build_manifest(
        root: str, mapping_file: Optional[str]
    ) -> List[Dict[str, Any]]:
        manifest = []
        if not os.path.isdir(root):
            return manifest
        # NHSS layout: Data/<singer>/<song>/Song.wav (+ Speech.wav + TextGrids)
        for song_wav in sorted(Path(root).rglob("Song.wav")):
            song_id = song_wav.parent.name
            singer_id = song_wav.parent.parent.name
            label_name = "vibrato"  # default coarse mapping; replaced if mapping file present
            label = VOCALSET_TECHNIQUES.index(label_name)
            manifest.append({
                "audio": str(song_wav),
                "singer": singer_id,
                "song": song_id,
                "technique": label_name,
                "label": label,
            })
        return manifest

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        item = self.manifest[idx]
        wav, _ = self._load_audio(item["audio"])
        wav = _segment_or_pad(wav, self.segment_samples)
        out: Dict[str, Any] = {
            "waveform": wav,
            "label": torch.tensor(item["label"], dtype=torch.long),
            "technique": item["technique"],
            "singer": item["singer"],
            "dataset": "NHSS",
        }
        if self.feature_pipeline is not None:
            out["mel"] = self.feature_pipeline.extract_mel(wav).squeeze(0)
        return out


class OpenSingerDataset(_BaseDataset):
    """OpenSinger Chinese pop / folk singing corpus."""

    def __init__(
        self,
        root_dir: str,
        target_sampling_rate: int = 16000,
        segment_seconds: float = 3.0,
        feature_pipeline=None,
        label_mapping_file: Optional[str] = None,
    ) -> None:
        manifest = self._build_manifest(root_dir, label_mapping_file)
        super().__init__(
            manifest=manifest,
            target_sampling_rate=target_sampling_rate,
            segment_seconds=segment_seconds,
            feature_pipeline=feature_pipeline,
        )

    @staticmethod
    def _build_manifest(
        root: str, mapping_file: Optional[str]
    ) -> List[Dict[str, Any]]:
        manifest = []
        if not os.path.isdir(root):
            return manifest
        for wav_path in sorted(Path(root).rglob("*.wav")):
            singer_song = wav_path.parent.name
            label_name = "forte"  # default coarse mapping
            label = VOCALSET_TECHNIQUES.index(label_name)
            manifest.append({
                "audio": str(wav_path),
                "singer_song": singer_song,
                "technique": label_name,
                "label": label,
            })
        return manifest

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        item = self.manifest[idx]
        wav, _ = self._load_audio(item["audio"])
        wav = _segment_or_pad(wav, self.segment_samples)
        out: Dict[str, Any] = {
            "waveform": wav,
            "label": torch.tensor(item["label"], dtype=torch.long),
            "technique": item["technique"],
            "singer_song": item["singer_song"],
            "dataset": "OpenSinger",
        }
        if self.feature_pipeline is not None:
            out["mel"] = self.feature_pipeline.extract_mel(wav).squeeze(0)
        return out


def build_dataloader(
    dataset: Dataset,
    batch_size: int,
    num_workers: int = 4,
    shuffle: bool = True,
    drop_last: bool = False,
) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        drop_last=drop_last,
        pin_memory=True,
    )


__all__ = [
    "AudioSample",
    "VOICEDDataset",
    "SVDDataset",
    "VocalSetDataset",
    "NHSSDataset",
    "OpenSingerDataset",
    "build_dataloader",
    "CROSSDOMAIN_LABEL_MAP",
]
