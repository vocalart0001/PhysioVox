"""
Sigmoid reparameterization for the LF glottal flow parameters.

Implements Equation (7) of the manuscript:
    O_q = O_q^min + (O_q^max - O_q^min) * sigmoid(Oq_hat)

The same form is applied to all five physiologically interpretable parameters
[Oq, Sq, Na, Rd, F0] so that the network output always lies within the
physiologically feasible region defined in Table 1 of the manuscript.
"""

from typing import Dict, Tuple

import torch
import torch.nn as nn


class PhysiologicalReparameterization(nn.Module):
    """
    Maps unconstrained neural-network output to physiologically feasible
    glottal-flow parameter ranges via Sigmoid reparameterization.

    Parameter bounds correspond to Table 1 of the manuscript:
        Oq (open quotient)         : [0.30, 0.90]
        Sq (speed quotient)        : [1.00, 5.00]
        Na (normalized amplitude)  : [0.05, 0.30]
        Rd (return quotient)       : [0.01, 0.30]
        F0 (fundamental frequency) : [80, 1000] Hz
    """

    PARAMETER_ORDER: Tuple[str, ...] = ("Oq", "Sq", "Na", "Rd", "F0")

    def __init__(self, parameter_bounds: Dict[str, Tuple[float, float]]) -> None:
        super().__init__()
        for name in self.PARAMETER_ORDER:
            if name not in parameter_bounds:
                raise KeyError(f"Missing parameter bound for '{name}'")

        lower = torch.tensor(
            [parameter_bounds[name][0] for name in self.PARAMETER_ORDER],
            dtype=torch.float32,
        )
        upper = torch.tensor(
            [parameter_bounds[name][1] for name in self.PARAMETER_ORDER],
            dtype=torch.float32,
        )
        self.register_buffer("lower", lower)
        self.register_buffer("upper", upper)

    def forward(self, raw: torch.Tensor) -> torch.Tensor:
        """
        Args:
            raw: Tensor of shape (..., 5) holding the unconstrained outputs
                 from the neural encoder.
        Returns:
            Tensor of shape (..., 5) holding the physiologically constrained
            parameters in the order [Oq, Sq, Na, Rd, F0].
        """
        if raw.shape[-1] != 5:
            raise ValueError(
                f"Expected last dimension of size 5, got {raw.shape[-1]}"
            )
        sig = torch.sigmoid(raw)
        return self.lower + (self.upper - self.lower) * sig

    def split(self, params: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Decomposes the (..., 5) tensor into a named dictionary."""
        return {
            name: params[..., idx]
            for idx, name in enumerate(self.PARAMETER_ORDER)
        }
