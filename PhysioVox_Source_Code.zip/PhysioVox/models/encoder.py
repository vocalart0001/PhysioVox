"""
Shared neural encoder: 6-layer Transformer with d_model=512, h=8 heads.

Architecture follows Figure 1 of the manuscript. The encoder takes an
80-dimensional Mel-spectrogram input and produces a generic voice
representation that is shared between the glottal source branch and the
vocal-tract filter branch during both pretraining and fine-tuning.
"""

import math

import torch
import torch.nn as nn


class SinusoidalPositionalEncoding(nn.Module):
    """Standard sinusoidal positional encoding."""

    def __init__(self, d_model: int, max_len: int = 8192) -> None:
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32)
            * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, : x.size(1)]


class SharedTransformerEncoder(nn.Module):
    """
    Six-layer Transformer encoder that maps Mel features (B, T, 80) to a
    shared latent representation (B, T, d_model).
    """

    def __init__(
        self,
        input_dim: int = 80,
        d_model: int = 512,
        n_heads: int = 8,
        n_layers: int = 6,
        d_ff: int = 2048,
        dropout: float = 0.1,
        max_len: int = 8192,
    ) -> None:
        super().__init__()
        self.input_projection = nn.Linear(input_dim, d_model)
        self.positional_encoding = SinusoidalPositionalEncoding(d_model, max_len)
        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=n_layers)
        self.layer_norm = nn.LayerNorm(d_model)
        self.d_model = d_model

    def forward(
        self,
        mel_features: torch.Tensor,
        src_key_padding_mask: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Args:
            mel_features: (B, T, input_dim) Mel-spectrogram features.
            src_key_padding_mask: optional (B, T) bool mask, True for padding.
        Returns:
            (B, T, d_model) latent representation.
        """
        x = self.input_projection(mel_features)
        x = self.positional_encoding(x)
        x = self.transformer(x, src_key_padding_mask=src_key_padding_mask)
        return self.layer_norm(x)
