"""
Differentiable Liljencrants-Fant (LF) glottal flow model.

This module implements the differentiable LF synthesizer described in
Section 3.2 of the manuscript. The classical LF model contains a hard
phase switch at the closure instant t = T_e, which makes the gradient
undefined at this point for backpropagation. We rewrite the phase
indicator with a Sigmoid function so that the entire synthesizer is
differentiable end-to-end.

Equations implemented:
    Eq. (3) — open-phase exponential-growth segment
    Eq. (4) — closed-phase exponential-decay segment
    Eq. (5) — Sigmoid phase indicator that replaces the hard switch
    Eq. (6) — combined differentiable glottal flow waveform

The five physiologically interpretable parameters
    psi = {Oq, Sq, Na, Rd, F0}
are derived from the network output through a one-to-one correspondence
with the microscopic LF parameters {E_e, alpha, omega_g, T_e, T_a, T_0}.
"""

from typing import Dict, Optional

import math
import torch
import torch.nn as nn


class DifferentiableLFSynthesizer(nn.Module):
    """
    Differentiable LF glottal flow synthesizer (Eqs. 3-6).

    The five interpretable parameters are passed in as a dictionary keyed by
    physiological name. Microscopic LF parameters are derived as follows:
        T_0     = 1 / F0
        T_e     = Oq * T_0
        T_a     = Rd * T_0
        omega_g = pi / (T_e * (Sq / (1 + Sq)))   # symmetry-based mapping
        E_e     = -Na / max_normalization
    """

    def __init__(
        self,
        sampling_rate: int = 16000,
        tau_ratio: float = 0.01,
        epsilon_init: float = 1.0e-3,
    ) -> None:
        super().__init__()
        self.sampling_rate = sampling_rate
        self.tau_ratio = tau_ratio
        # Numerical floor to prevent division-by-zero during early training.
        self.eps = epsilon_init

    @staticmethod
    def _phase_indicator(
        t: torch.Tensor, t_e: torch.Tensor, tau: torch.Tensor
    ) -> torch.Tensor:
        """
        Equation (5): Sigmoid phase indicator replacing the hard switch.
            phi(t; T_e, tau) = sigmoid((t - T_e) / tau)
        """
        return torch.sigmoid((t - t_e) / tau)

    @staticmethod
    def _open_phase(
        t: torch.Tensor,
        e_e: torch.Tensor,
        alpha: torch.Tensor,
        omega_g: torch.Tensor,
        t_e: torch.Tensor,
    ) -> torch.Tensor:
        """
        Equation (3): open-phase exponential-growth segment.
            g_open(t) = E_e * [exp(alpha*t) * sin(omega_g * t)]
                              / [exp(alpha*T_e) * sin(omega_g * T_e)]
        Numerically stabilised by clamping the denominator away from zero.
        """
        num = torch.exp(alpha * t) * torch.sin(omega_g * t)
        denom = torch.exp(alpha * t_e) * torch.sin(omega_g * t_e)
        denom = torch.where(
            torch.abs(denom) < 1.0e-6,
            torch.full_like(denom, 1.0e-6),
            denom,
        )
        return e_e * num / denom

    @staticmethod
    def _closed_phase(
        t: torch.Tensor,
        e_e: torch.Tensor,
        epsilon: torch.Tensor,
        t_e: torch.Tensor,
        t_a: torch.Tensor,
        t_c: torch.Tensor,
    ) -> torch.Tensor:
        """
        Equation (4): closed-phase exponential-decay segment.
            g_close(t) = -E_e / (epsilon * T_a)
                        * [exp(-epsilon*(t - T_e)) - exp(-epsilon*(T_c - T_e))]
        """
        eps_ta = epsilon * t_a
        eps_ta = torch.where(
            torch.abs(eps_ta) < 1.0e-6,
            torch.full_like(eps_ta, 1.0e-6),
            eps_ta,
        )
        decay_now = torch.exp(-epsilon * (t - t_e))
        decay_end = torch.exp(-epsilon * (t_c - t_e))
        return -(e_e / eps_ta) * (decay_now - decay_end)

    def _derive_microscopic_parameters(
        self,
        psi: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """
        Maps the five interpretable parameters to the classical LF
        microscopic parameters. See Section 3.2 of the manuscript.
        """
        f0 = psi["F0"].clamp(min=20.0)
        oq = psi["Oq"].clamp(min=1.0e-3, max=0.999)
        sq = psi["Sq"].clamp(min=1.0e-3)
        na = psi["Na"]
        rd = psi["Rd"].clamp(min=1.0e-4)

        t_0 = 1.0 / f0
        t_e = oq * t_0
        t_a = rd * t_0
        t_c = t_0

        # Open-phase symmetry-based oscillation angular frequency.
        # When Sq=1 the open phase is symmetric and omega_g = pi / T_e.
        omega_g = math.pi * (1.0 + sq) / (t_e * sq)

        # Exponential growth rate alpha determined from the requirement that
        # the LF waveform integrates to zero over one period (standard LF
        # consistency condition). For a stable differentiable surrogate we
        # use alpha = 1 / T_e which preserves the open-phase shape.
        alpha = 1.0 / t_e

        # Closed-phase decay parameter solved from the boundary condition.
        # We use the standard analytical approximation epsilon * T_a = 1 - exp(-epsilon*(T_c - T_e))
        # solved iteratively; the small-signal limit gives epsilon ≈ 1 / T_a.
        epsilon = 1.0 / t_a

        # Negative-peak amplitude proportional to the normalized amplitude.
        e_e = -na * 10.0  # Scaling factor that keeps gradients well-conditioned.

        return {
            "T_0": t_0,
            "T_e": t_e,
            "T_a": t_a,
            "T_c": t_c,
            "alpha": alpha,
            "omega_g": omega_g,
            "epsilon": epsilon,
            "E_e": e_e,
        }

    def forward(
        self,
        psi: Dict[str, torch.Tensor],
        num_samples: int,
        time_offset: float = 0.0,
    ) -> torch.Tensor:
        """
        Synthesises the glottal flow waveform for a batch of parameter sets.

        Args:
            psi: dictionary with keys {Oq, Sq, Na, Rd, F0}, each of shape
                 (B,) or (B, T_frames).
            num_samples: number of time samples to synthesise.
            time_offset: optional time origin offset in seconds.

        Returns:
            Tensor of shape (B, num_samples) holding the glottal flow.
        """
        # Broadcast all parameters to the same leading shape.
        ref = psi["F0"]
        if ref.ndim == 1:
            psi_b = {k: v.unsqueeze(-1) for k, v in psi.items()}  # (B, 1)
        else:
            psi_b = psi

        micro = self._derive_microscopic_parameters(psi_b)

        # Construct the time axis (samples), wrapped within each fundamental
        # period to obtain the periodic glottal-flow waveform.
        device = ref.device
        dtype = ref.dtype
        t_full = (
            torch.arange(num_samples, device=device, dtype=dtype)
            / self.sampling_rate
        ) + time_offset
        # Shape adapt: (1, num_samples) broadcastable with (B, 1).
        t_full = t_full.view(1, -1)

        t_0 = micro["T_0"]
        # Phase within current period [0, T_0).
        t_mod = torch.remainder(t_full, t_0)

        # Sigmoid smoothing factor: tau = T_0 / 100 (Section 3.2).
        tau = self.tau_ratio * t_0

        # Open- and closed-phase contributions evaluated at every sample.
        g_open = self._open_phase(
            t_mod, micro["E_e"], micro["alpha"],
            micro["omega_g"], micro["T_e"],
        )
        g_close = self._closed_phase(
            t_mod, micro["E_e"], micro["epsilon"],
            micro["T_e"], micro["T_a"], micro["T_c"],
        )

        # Equation (6): differentiable phase-weighted combination.
        phi = self._phase_indicator(t_mod, micro["T_e"], tau)
        g_theta = (1.0 - phi) * g_open + phi * g_close

        return g_theta

    def spectral_envelope(
        self,
        psi: Dict[str, torch.Tensor],
        num_samples: int,
    ) -> torch.Tensor:
        """
        Returns the magnitude spectrum of the synthesised glottal flow, used
        by the decoupling regularization in Equation (10).
        """
        g_theta = self.forward(psi, num_samples=num_samples)
        spec = torch.fft.rfft(g_theta, dim=-1)
        return torch.abs(spec)
