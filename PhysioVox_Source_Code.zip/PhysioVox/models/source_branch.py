"""
Glottal Source Parameter Estimator.

Maps the shared latent representation produced by the Transformer encoder
to the five physiologically interpretable LF parameters
    psi = {Oq, Sq, Na, Rd, F0}.
The 5-D output is constrained to the physiologically feasible region by
the PhysiologicalReparameterization module (Eq. 7).
"""

from typing import Dict, Tuple

import torch
import torch.nn as nn

from .reparametrize import PhysiologicalReparameterization


class GlottalSourceBranch(nn.Module):
    """
    Two-layer MLP head that predicts the 5-D unconstrained LF parameters,
    followed by Sigmoid reparameterization to the physiological range.
    """

    def __init__(
        self,
        d_model: int = 512,
        hidden_dim: int = 256,
        parameter_bounds: Dict[str, Tuple[float, float]] = None,
        temporal_pool: str = "mean",
    ) -> None:
        super().__init__()
        if parameter_bounds is None:
            parameter_bounds = {
                "Oq": (0.30, 0.90),
                "Sq": (1.00, 5.00),
                "Na": (0.05, 0.30),
                "Rd": (0.01, 0.30),
                "F0": (80.0, 1000.0),
            }
        self.temporal_pool = temporal_pool

        self.head = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, 5),
        )
        self.reparametrize = PhysiologicalReparameterization(parameter_bounds)

    def _pool(self, x: torch.Tensor) -> torch.Tensor:
        if self.temporal_pool == "mean":
            return x.mean(dim=1)
        if self.temporal_pool == "max":
            return x.max(dim=1).values
        raise ValueError(f"Unknown pooling strategy: {self.temporal_pool}")

    def forward(
        self,
        latent: torch.Tensor,
        return_frame_level: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            latent: (B, T, d_model) shared encoder output.
            return_frame_level: if True, also returns per-frame parameter
                estimates (used by the vibrato causal-consistency loss for
                F0 modulation analysis).

        Returns:
            Dictionary containing:
                'psi'        : (B, 5)         physiological parameters
                'psi_dict'   : dict with 5 named (B,) tensors
                'psi_frames' : (B, T, 5) optional per-frame parameters
        """
        # Per-frame raw outputs allow frame-level analysis of F0 modulation.
        raw_frame = self.head(latent)  # (B, T, 5)
        psi_frame = self.reparametrize(raw_frame)  # (B, T, 5)

        # Utterance-level summary used for synthesis and classification.
        latent_pooled = self._pool(latent)  # (B, d_model)
        raw_pooled = self.head(latent_pooled)  # (B, 5)
        psi_utt = self.reparametrize(raw_pooled)  # (B, 5)

        out = {
            "psi": psi_utt,
            "psi_dict": self.reparametrize.split(psi_utt),
        }
        if return_frame_level:
            out["psi_frames"] = psi_frame
        return out
