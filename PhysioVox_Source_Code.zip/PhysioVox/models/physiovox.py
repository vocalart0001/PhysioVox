"""
PhysioVox: full model assembly.

This module composes the shared encoder, glottal source branch, vocal-tract
filter branch, differentiable LF synthesizer, and the technique classifier
into one end-to-end trainable network. The architecture follows Figure 1
of the manuscript: a 5-layer pipeline (waveform -> features -> encoder ->
two branches with shared physical substrate -> two task heads).
"""

from typing import Any, Dict, Optional

import torch
import torch.nn as nn

from .encoder import SharedTransformerEncoder
from .filter_branch import VocalTractFilterBranch
from .lf_synthesizer import DifferentiableLFSynthesizer
from .source_branch import GlottalSourceBranch


class PhysioVoxModel(nn.Module):
    """End-to-end PhysioVox model with multi-task outputs."""

    def __init__(self, config: Dict[str, Any]) -> None:
        super().__init__()
        self.config = config

        encoder_cfg = config["model"]["encoder"]
        source_cfg = config["model"]["source_branch"]
        filter_cfg = config["model"]["filter_branch"]
        lf_cfg = config["model"]["lf_synthesizer"]
        cls_cfg = config["model"]["classifier"]

        self.encoder = SharedTransformerEncoder(
            input_dim=config["audio"]["n_mels"],
            d_model=encoder_cfg["d_model"],
            n_heads=encoder_cfg["n_heads"],
            n_layers=encoder_cfg["n_layers"],
            d_ff=encoder_cfg["d_ff"],
            dropout=encoder_cfg["dropout"],
        )
        self.source_branch = GlottalSourceBranch(
            d_model=encoder_cfg["d_model"],
            hidden_dim=source_cfg["hidden_dim"],
            parameter_bounds=lf_cfg["parameter_bounds"],
        )
        self.filter_branch = VocalTractFilterBranch(
            d_model=encoder_cfg["d_model"],
            hidden_dim=filter_cfg["hidden_dim"],
            lpc_order=filter_cfg["lpc_order"],
        )
        self.lf_enabled = lf_cfg.get("enabled", True)
        self.lf_synthesizer = DifferentiableLFSynthesizer(
            sampling_rate=config["audio"]["sampling_rate"],
            tau_ratio=lf_cfg["tau_ratio"],
        )

        # Generic MLP fallback used when the LF topology is ablated.
        encoder_dim = encoder_cfg["d_model"]
        self.fallback_excitation_head = nn.Sequential(
            nn.Linear(encoder_dim, source_cfg["hidden_dim"]),
            nn.GELU(),
            nn.Linear(source_cfg["hidden_dim"], encoder_dim),
        )

        # 17-class technique classification head (Section 4.2).
        self.classifier = nn.Sequential(
            nn.Linear(encoder_dim, encoder_dim),
            nn.GELU(),
            nn.Dropout(cls_cfg["dropout"]),
            nn.Linear(encoder_dim, cls_cfg["n_classes"]),
        )

        # Sample count for synthesised glottal waveform during a forward pass
        # (used by L_phys and L_reg). Defaults to 1 second at the configured
        # sample rate; can be overridden per forward call.
        self.default_synth_samples = config["audio"]["sampling_rate"]

    def forward(
        self,
        mel: torch.Tensor,
        synth_samples: Optional[int] = None,
        return_frame_level: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            mel: (B, T_frames, n_mels) Mel-spectrogram input.
            synth_samples: number of waveform samples to synthesise; defaults
                to the configured sample rate (1 second).
            return_frame_level: whether to return per-frame physiological
                parameter estimates (required for the vibrato causal loss).

        Returns:
            Dictionary with the following keys:
                'latent'          : (B, T, d_model) shared encoder output
                'psi'             : (B, 5) physiological LF parameters
                'psi_dict'        : dict of 5 named (B,) tensors
                'psi_frames'      : (B, T, 5) per-frame LF parameters
                'phi'             : (B, 16) filter parameters
                'lpc_coeffs'      : (B, 12) LPC coefficients
                'formants'        : (B, 4) formant frequencies in Hz
                'glottal_flow'    : (B, N) LF-synthesised glottal flow
                'reconstructed'   : (B, N) reconstructed speech waveform
                'logits'          : (B, n_classes) classification logits
        """
        if synth_samples is None:
            synth_samples = self.default_synth_samples

        latent = self.encoder(mel)
        source_out = self.source_branch(latent, return_frame_level=return_frame_level)
        filter_out = self.filter_branch(latent)

        # Pooled utterance-level latent for classification.
        pooled = latent.mean(dim=1)
        logits = self.classifier(pooled)

        outputs: Dict[str, torch.Tensor] = {
            "latent": latent,
            "psi": source_out["psi"],
            "psi_dict": source_out["psi_dict"],
            "phi": filter_out["phi"],
            "lpc_coeffs": filter_out["lpc_coeffs"],
            "formants": filter_out["formants"],
            "logits": logits,
        }
        if "psi_frames" in source_out:
            outputs["psi_frames"] = source_out["psi_frames"]

        # Synthesise glottal flow if the differentiable LF topology is active.
        if self.lf_enabled:
            glottal_flow = self.lf_synthesizer(
                source_out["psi_dict"], num_samples=synth_samples
            )
            reconstructed = VocalTractFilterBranch.apply_filter(
                glottal_flow, filter_out["lpc_coeffs"]
            )
            outputs["glottal_flow"] = glottal_flow
            outputs["reconstructed"] = reconstructed
        else:
            # Generic MLP-based fallback used in the "w/o differentiable LF" ablation.
            excitation_seed = self.fallback_excitation_head(pooled)
            # Project the seed to a waveform-length signal via a tiny up-sampler.
            tiled = excitation_seed.unsqueeze(-1).repeat(1, 1, synth_samples // excitation_seed.shape[-1] + 1)
            outputs["glottal_flow"] = tiled[:, 0, :synth_samples]
            outputs["reconstructed"] = outputs["glottal_flow"].clone()

        return outputs

    def load_pretrained_encoder(self, checkpoint_path: str) -> None:
        """Loads encoder + source + filter weights from a pretrain checkpoint."""
        state = torch.load(checkpoint_path, map_location="cpu")
        own = self.state_dict()
        transferred = 0
        for key, value in state.get("model_state", state).items():
            if key in own and own[key].shape == value.shape:
                own[key] = value
                transferred += 1
        self.load_state_dict(own)
        return transferred
