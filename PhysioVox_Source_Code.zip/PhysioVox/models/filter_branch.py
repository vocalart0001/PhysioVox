"""
Vocal-Tract Filter Branch.

Estimates the LPC-12 vocal-tract filter coefficients (Figure 1 of the
manuscript) from the shared encoder output. The estimated filter response
is convolved with the glottal flow waveform from the LF synthesizer to
produce the reconstructed speech waveform (Eq. 8).
"""

from typing import Dict

import torch
import torch.nn as nn
import torch.nn.functional as F


class VocalTractFilterBranch(nn.Module):
    """
    Predicts LPC-12 reflection coefficients and converts them to direct-form
    LPC coefficients for time-domain filtering of the glottal flow.
    """

    def __init__(
        self,
        d_model: int = 512,
        hidden_dim: int = 256,
        lpc_order: int = 12,
        temporal_pool: str = "mean",
    ) -> None:
        super().__init__()
        self.lpc_order = lpc_order
        self.temporal_pool = temporal_pool

        # We predict 4 additional formant-related summary statistics
        # (F1..F4 centre frequencies) for the resonance-based causal
        # constraint on the "belt" technique (F1 > 750 Hz, Section 3.4).
        self.coefficient_head = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, lpc_order),
        )
        self.formant_head = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 4),
        )

    def _pool(self, x: torch.Tensor) -> torch.Tensor:
        if self.temporal_pool == "mean":
            return x.mean(dim=1)
        return x.max(dim=1).values

    @staticmethod
    def _reflection_to_lpc(reflection: torch.Tensor) -> torch.Tensor:
        """
        Step-up Levinson-Durbin recursion converting reflection coefficients
        k_1, ..., k_p to direct-form LPC coefficients a_1, ..., a_p.
        Reflection coefficients are constrained to (-1, 1) via tanh so that
        the resulting all-pole filter is guaranteed to be stable.
        """
        k = torch.tanh(reflection)  # ensure |k_i| < 1
        batch_size, p = k.shape
        device = k.device
        dtype = k.dtype

        a = torch.zeros(batch_size, p, device=device, dtype=dtype)
        a[:, 0] = k[:, 0]
        for i in range(1, p):
            ki = k[:, i].unsqueeze(-1)
            prev = a[:, :i].clone()
            a[:, :i] = prev + ki * prev.flip(-1)
            a[:, i] = k[:, i]
        return a

    def forward(self, latent: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            latent: (B, T, d_model) shared encoder output.
        Returns:
            Dictionary containing:
                'lpc_coeffs' : (B, lpc_order) direct-form LPC coefficients
                'formants'   : (B, 4) formant centre frequencies in Hz
                'phi'        : (B, lpc_order + 4) packaged filter parameters
        """
        pooled = self._pool(latent)
        reflection = self.coefficient_head(pooled)  # (B, lpc_order)
        lpc = self._reflection_to_lpc(reflection)
        # Formant frequencies bounded to a plausible vocal-tract range
        # (200 Hz to 4000 Hz).
        formant_raw = self.formant_head(pooled)
        formants = 200.0 + 3800.0 * torch.sigmoid(formant_raw)

        return {
            "lpc_coeffs": lpc,
            "reflection": reflection,
            "formants": formants,
            "phi": torch.cat([lpc, formants], dim=-1),
        }

    @staticmethod
    def apply_filter(
        excitation: torch.Tensor, lpc_coeffs: torch.Tensor
    ) -> torch.Tensor:
        """
        Applies the all-pole LPC filter to the excitation waveform in the
        time domain using a recursive IIR formulation.

        Args:
            excitation : (B, N) glottal flow waveform from the LF synthesizer.
            lpc_coeffs : (B, p) direct-form LPC coefficients a_1, ..., a_p.
        Returns:
            (B, N) reconstructed speech waveform.
        """
        batch_size, n_samples = excitation.shape
        order = lpc_coeffs.shape[-1]
        device = excitation.device
        dtype = excitation.dtype

        y = torch.zeros_like(excitation)
        # IIR recursion with circular history buffer.
        history = torch.zeros(batch_size, order, device=device, dtype=dtype)
        for n in range(n_samples):
            # y[n] = x[n] - sum_{i=1..p} a_i * y[n-i]
            feedback = (lpc_coeffs * history).sum(dim=-1)
            y[:, n] = excitation[:, n] - feedback
            history = torch.roll(history, shifts=1, dims=-1)
            history[:, 0] = y[:, n]
        return y
