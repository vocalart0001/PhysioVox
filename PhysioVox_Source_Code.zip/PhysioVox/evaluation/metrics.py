"""
Classification and regression evaluation metrics.

Provides:
    - Accuracy, Macro-F1, Weighted-F1 for the 17-class technique task
      (Section 4.2 of the manuscript).
    - Pearson correlation coefficient, MAE and RMSE for the five-dimensional
      physiological parameter estimation task (Section 4.4).
    - Wasserstein distance between source-domain and target-domain
      representations (Section 4.1).
"""

from typing import Dict, Sequence

import numpy as np
import torch
from scipy.stats import pearsonr
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
)


def classification_metrics(
    y_true: Sequence[int],
    y_pred: Sequence[int],
) -> Dict[str, float]:
    """Computes Accuracy, Macro-F1 and Weighted-F1."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
    }


def normalised_confusion_matrix(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    num_classes: int = 17,
) -> np.ndarray:
    """Row-normalised confusion matrix (rows sum to one when the row is non-zero)."""
    cm = confusion_matrix(
        y_true, y_pred, labels=list(range(num_classes))
    ).astype(np.float64)
    row_sums = cm.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    return cm / row_sums


def physiological_estimation_metrics(
    predictions: Dict[str, np.ndarray],
    targets: Dict[str, np.ndarray],
) -> Dict[str, Dict[str, float]]:
    """
    Computes MAE, RMSE and Pearson r for each physiological parameter.

    Args:
        predictions: dictionary keyed by parameter name (Oq, Sq, Na, Rd, F0).
        targets: dictionary with the same keys holding the ground truth.
    Returns:
        Nested dictionary {param_name: {mae, rmse, pearson_r}}.
    """
    out: Dict[str, Dict[str, float]] = {}
    for name in ("Oq", "Sq", "Na", "Rd", "F0"):
        pred = np.asarray(predictions[name]).ravel()
        tgt = np.asarray(targets[name]).ravel()
        if pred.size == 0 or tgt.size == 0:
            continue
        n = min(pred.size, tgt.size)
        pred = pred[:n]
        tgt = tgt[:n]
        mae = float(np.mean(np.abs(pred - tgt)))
        rmse = float(np.sqrt(np.mean((pred - tgt) ** 2)))
        if np.std(pred) < 1.0e-12 or np.std(tgt) < 1.0e-12:
            r = 0.0
        else:
            r, _ = pearsonr(pred, tgt)
        out[name] = {"mae": mae, "rmse": rmse, "pearson_r": float(r)}
    return out


def representation_wasserstein(
    source_features: np.ndarray,
    target_features: np.ndarray,
) -> float:
    """
    Estimates the inter-domain representation Wasserstein-1 distance.

    Uses the closed-form solution for univariate empirical distributions on
    each feature dimension and averages across dimensions.
    """
    if source_features.ndim != 2 or target_features.ndim != 2:
        raise ValueError("Expected 2-D feature matrices (N x D).")
    d = min(source_features.shape[1], target_features.shape[1])
    dists = []
    for i in range(d):
        src = np.sort(source_features[:, i])
        tgt = np.sort(target_features[:, i])
        # Resample to the same length using linear interpolation in quantile space.
        n = max(len(src), len(tgt))
        u = np.linspace(0, 1, n)
        src_q = np.interp(u, np.linspace(0, 1, len(src)), src)
        tgt_q = np.interp(u, np.linspace(0, 1, len(tgt)), tgt)
        dists.append(np.mean(np.abs(src_q - tgt_q)))
    return float(np.mean(dists))


@torch.no_grad()
def collect_predictions(
    model: torch.nn.Module,
    dataloader,
    device: torch.device,
) -> Dict[str, np.ndarray]:
    """Runs the model on a dataloader and returns logits + labels + features."""
    model.eval()
    all_logits = []
    all_labels = []
    all_features = []
    all_psi = []
    for batch in dataloader:
        mel = batch["mel"].to(device)
        outputs = model(mel)
        all_logits.append(outputs["logits"].cpu().numpy())
        all_features.append(outputs["latent"].mean(dim=1).cpu().numpy())
        all_psi.append(outputs["psi"].cpu().numpy())
        if "label" in batch:
            all_labels.append(batch["label"].cpu().numpy())

    return {
        "logits": np.concatenate(all_logits, axis=0) if all_logits else np.zeros((0, 17)),
        "labels": np.concatenate(all_labels, axis=0) if all_labels else np.zeros((0,)),
        "features": np.concatenate(all_features, axis=0) if all_features else np.zeros((0, 512)),
        "psi": np.concatenate(all_psi, axis=0) if all_psi else np.zeros((0, 5)),
    }


__all__ = [
    "classification_metrics",
    "normalised_confusion_matrix",
    "physiological_estimation_metrics",
    "representation_wasserstein",
    "collect_predictions",
]
