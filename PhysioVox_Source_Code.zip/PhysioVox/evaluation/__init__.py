"""Evaluation utilities for PhysioVox (metrics, cross-domain, ablation, physiology)."""

from .ablation import loss_weight_sensitivity, run_ablation_suite
from .crossdomain import evaluate_cross_domain
from .metrics import (
    classification_metrics,
    collect_predictions,
    normalised_confusion_matrix,
    physiological_estimation_metrics,
    representation_wasserstein,
)
from .physiological import evaluate_physiological_accuracy

__all__ = [
    "classification_metrics",
    "normalised_confusion_matrix",
    "physiological_estimation_metrics",
    "representation_wasserstein",
    "collect_predictions",
    "evaluate_cross_domain",
    "run_ablation_suite",
    "loss_weight_sensitivity",
    "evaluate_physiological_accuracy",
]
