"""
Cross-domain zero-shot evaluation on NHSS and OpenSinger.

After fine-tuning on VocalSet, the model is evaluated zero-shot on the
two external datasets whose labels are coarsely mapped onto the five
principal VocalSet technique classes (vibrato, breathy, vocal fry, forte,
piano). See Section 4.2 of the manuscript.
"""

from typing import Any, Dict

import numpy as np
import torch

from data_processing import (
    FeaturePipeline,
    NHSSDataset,
    OpenSingerDataset,
    build_dataloader,
)
from models import PhysioVoxModel

from .metrics import classification_metrics, collect_predictions


# Five principal VocalSet classes used for coarse cross-domain evaluation.
CROSS_DOMAIN_INDICES = [0, 2, 3, 10, 11]   # vibrato, breathy, vocal_fry, forte, piano


def _collapse_to_five_class(logits: np.ndarray, labels: np.ndarray):
    """Restricts predictions and labels to the five principal classes."""
    sub_logits = logits[:, CROSS_DOMAIN_INDICES]
    pred = np.argmax(sub_logits, axis=-1)
    # Remap original 17-class labels to 0-4 indices within CROSS_DOMAIN_INDICES.
    label_to_idx = {orig: i for i, orig in enumerate(CROSS_DOMAIN_INDICES)}
    mapped = np.array([label_to_idx.get(int(y), 0) for y in labels])
    return pred, mapped


def evaluate_cross_domain(
    model: PhysioVoxModel,
    config: Dict[str, Any],
    nhss_root: str,
    opensinger_root: str,
    device: torch.device,
) -> Dict[str, Dict[str, float]]:
    feature_pipeline = FeaturePipeline(config)
    results: Dict[str, Dict[str, float]] = {}

    for name, dataset_cls, root in (
        ("NHSS", NHSSDataset, nhss_root),
        ("OpenSinger", OpenSingerDataset, opensinger_root),
    ):
        ds = dataset_cls(
            root_dir=root,
            target_sampling_rate=config["audio"]["sampling_rate"],
            segment_seconds=config["audio"]["segment_seconds"],
            feature_pipeline=feature_pipeline,
        )
        if len(ds) == 0:
            continue
        loader = build_dataloader(
            ds,
            batch_size=config["training"]["finetune"]["batch_size"],
            num_workers=config["experiment"]["num_workers"],
            shuffle=False,
        )
        preds = collect_predictions(model, loader, device)
        y_pred, y_true = _collapse_to_five_class(preds["logits"], preds["labels"])
        results[name] = classification_metrics(y_true, y_pred)
    return results
