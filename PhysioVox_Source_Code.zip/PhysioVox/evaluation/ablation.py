"""
Module ablation runner.

Implements the systematic ablation study reported in Section 4.3 (Table 5
and Figure 10) of the manuscript. Each ablation variant disables one core
PhysioVox component and re-trains end-to-end, allowing measurement of
the contribution carried by that component.
"""

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List

import torch
import yaml

from data_processing import FeaturePipeline, VocalSetDataset, build_dataloader
from models import PhysioVoxModel
from training.finetune import run_finetune

from .metrics import classification_metrics, collect_predictions


def _apply_overrides(base: Dict[str, Any], overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merges overrides into a copy of base."""
    out = deepcopy(base)

    def _merge(dst, src):
        for key, value in src.items():
            if isinstance(value, dict) and isinstance(dst.get(key), dict):
                _merge(dst[key], value)
            else:
                dst[key] = value

    _merge(out, overrides)
    return out


def run_ablation_suite(
    base_config: Dict[str, Any],
    ablation_config: Dict[str, Any],
    vocalset_root: str,
    pretrained_checkpoint: str = None,
) -> Dict[str, Dict[str, float]]:
    """
    Runs all ablation variants defined in ablation_config['ablations'].

    Returns a mapping {variant_name: {accuracy, macro_f1, weighted_f1}}.
    """
    results: Dict[str, Dict[str, float]] = {}
    feature_pipeline = FeaturePipeline(base_config)

    val_dataset = VocalSetDataset(
        root_dir=vocalset_root,
        target_sampling_rate=base_config["audio"]["sampling_rate"],
        segment_seconds=base_config["audio"]["segment_seconds"],
        feature_pipeline=feature_pipeline,
    )
    val_loader = build_dataloader(
        val_dataset,
        batch_size=base_config["training"]["finetune"]["batch_size"],
        num_workers=base_config["experiment"]["num_workers"],
        shuffle=False,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    for variant_name, variant_spec in ablation_config["ablations"].items():
        merged_config = _apply_overrides(base_config, variant_spec.get("overrides", {}))
        ckpt = pretrained_checkpoint
        if variant_name in ("no_egg_pretraining", "backbone_only"):
            ckpt = None
        outcome = run_finetune(
            config=merged_config,
            vocalset_root=vocalset_root,
            pretrained_checkpoint=ckpt,
        )
        ckpt_path = (
            Path(merged_config["logging"]["output_dir"]) / "checkpoints" / outcome["checkpoint"]
        )
        model = PhysioVoxModel(merged_config).to(device)
        if ckpt_path.exists():
            state = torch.load(ckpt_path, map_location=device)
            model.load_state_dict(state["model_state"])
        preds = collect_predictions(model, val_loader, device)
        if preds["logits"].size > 0:
            y_pred = preds["logits"].argmax(axis=-1)
            results[variant_name] = classification_metrics(preds["labels"], y_pred)
        else:
            results[variant_name] = {"accuracy": 0.0, "macro_f1": 0.0, "weighted_f1": 0.0}

    return results


def loss_weight_sensitivity(
    base_config: Dict[str, Any],
    ablation_config: Dict[str, Any],
    vocalset_root: str,
    pretrained_checkpoint: str = None,
) -> Dict[str, Any]:
    """
    Bivariate sweep over (lambda_phys, lambda_caus) for Figure 11.

    Returns the Macro-F1 surface evaluated on the held-out VocalSet
    validation fold for each (lambda_phys, lambda_caus) combination.
    """
    lambda_phys_grid = ablation_config["loss_weight_grid"]["lambda_phys_values"]
    lambda_caus_grid = ablation_config["loss_weight_grid"]["lambda_caus_values"]
    grid_results: List[Dict[str, Any]] = []

    for l_phys in lambda_phys_grid:
        for l_caus in lambda_caus_grid:
            cfg = deepcopy(base_config)
            cfg["losses"]["physical"]["weight_finetune"] = l_phys
            cfg["losses"]["causal"]["weight_finetune"] = l_caus
            outcome = run_finetune(
                config=cfg,
                vocalset_root=vocalset_root,
                pretrained_checkpoint=pretrained_checkpoint,
            )
            grid_results.append({
                "lambda_phys": l_phys,
                "lambda_caus": l_caus,
                "history": outcome["history"],
            })

    return {
        "lambda_phys_values": lambda_phys_grid,
        "lambda_caus_values": lambda_caus_grid,
        "grid_results": grid_results,
    }
