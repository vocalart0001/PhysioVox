"""
Physiological parameter estimation accuracy.

Evaluates the five-dimensional physiological output {Oq, Sq, Na, Rd, F0}
of PhysioVox against ground-truth values extracted from EGG analysis on
a held-out subset of the clinical source-domain corpora (VOICED + SVD).
Used to produce Table 6 of the manuscript.
"""

from typing import Any, Dict, List

import numpy as np
import torch
from torch.utils.data import ConcatDataset

from data_processing import (
    FeaturePipeline,
    SVDDataset,
    VOICEDDataset,
    build_dataloader,
)
from models import PhysioVoxModel

from .metrics import physiological_estimation_metrics


PARAM_ORDER = ("Oq", "Sq", "Na", "Rd", "F0")


def _extract_ground_truth_from_egg(
    egg_signal: np.ndarray,
    sampling_rate: int = 16000,
) -> Dict[str, float]:
    """
    Extracts the five physiological parameters from an EGG waveform via
    closed-form glottal-flow analysis (Henrich et al., 2005 conventions).
    """
    egg = egg_signal.astype(np.float64)
    if egg.size < 4:
        return {name: 0.0 for name in PARAM_ORDER}

    # Differentiated EGG to detect glottal closure / opening instants.
    degg = np.diff(egg)
    closure_threshold = np.std(degg) * 1.5
    closures = np.where(degg < -closure_threshold)[0]
    openings = np.where(degg > closure_threshold)[0]

    if closures.size < 2 or openings.size < 1:
        return {name: float("nan") for name in PARAM_ORDER}

    # Period from successive closures.
    periods = np.diff(closures) / sampling_rate
    t0 = float(np.median(periods))
    f0 = 1.0 / t0 if t0 > 0 else 0.0

    # Open quotient: ratio of open phase length to cycle period.
    open_phase_samples: List[int] = []
    for c_idx in closures[:-1]:
        nxt_open = openings[openings > c_idx]
        if nxt_open.size == 0:
            continue
        open_phase_samples.append(int(nxt_open[0] - c_idx))
    open_quotient = (
        float(np.median(open_phase_samples)) / (t0 * sampling_rate)
        if open_phase_samples else 0.0
    )

    # Speed quotient: opening duration / closing duration.
    sq_samples: List[float] = []
    for c_idx in closures[:-1]:
        nxt_open = openings[openings > c_idx]
        next_close = closures[closures > c_idx]
        if nxt_open.size == 0 or next_close.size == 0:
            continue
        op = nxt_open[0]
        nc = next_close[0]
        if nc - op == 0 or op - c_idx == 0:
            continue
        sq_samples.append((op - c_idx) / max(1, nc - op))
    speed_quotient = float(np.median(sq_samples)) if sq_samples else 1.0

    # Normalised amplitude: maximum negative DEGG peak normalised by period.
    max_negative = float(np.max(-degg))
    n_a = max_negative / max(np.std(egg), 1.0e-6)
    n_a = float(np.clip(n_a * 0.05, 0.05, 0.30))

    # Return-phase quotient: tail length after closure.
    decay_lengths: List[int] = []
    for c_idx in closures:
        tail = degg[c_idx:min(c_idx + 100, len(degg))]
        crossings = np.where(np.abs(tail) < closure_threshold * 0.3)[0]
        if crossings.size > 0:
            decay_lengths.append(int(crossings[0]))
    return_quotient = (
        float(np.median(decay_lengths)) / (t0 * sampling_rate)
        if decay_lengths else 0.05
    )

    return {
        "Oq": float(np.clip(open_quotient, 0.30, 0.90)),
        "Sq": float(np.clip(speed_quotient, 1.00, 5.00)),
        "Na": float(np.clip(n_a, 0.05, 0.30)),
        "Rd": float(np.clip(return_quotient, 0.01, 0.30)),
        "F0": float(np.clip(f0, 80.0, 1000.0)),
    }


def evaluate_physiological_accuracy(
    model: PhysioVoxModel,
    config: Dict[str, Any],
    voiced_root: str,
    svd_root: str,
    device: torch.device,
) -> Dict[str, Dict[str, float]]:
    feature_pipeline = FeaturePipeline(config)
    datasets = []
    if voiced_root:
        datasets.append(VOICEDDataset(
            root_dir=voiced_root,
            target_sampling_rate=config["audio"]["sampling_rate"],
            segment_seconds=config["audio"]["segment_seconds"],
            feature_pipeline=feature_pipeline,
        ))
    if svd_root:
        datasets.append(SVDDataset(
            root_dir=svd_root,
            target_sampling_rate=config["audio"]["sampling_rate"],
            segment_seconds=config["audio"]["segment_seconds"],
            feature_pipeline=feature_pipeline,
        ))

    if not datasets:
        return {name: {"mae": 0.0, "rmse": 0.0, "pearson_r": 0.0} for name in PARAM_ORDER}

    loader = build_dataloader(
        ConcatDataset(datasets),
        batch_size=config["training"]["pretrain"]["batch_size"],
        num_workers=config["experiment"]["num_workers"],
        shuffle=False,
    )

    pred_buffers: Dict[str, List[float]] = {name: [] for name in PARAM_ORDER}
    target_buffers: Dict[str, List[float]] = {name: [] for name in PARAM_ORDER}

    model.eval()
    sampling_rate = config["audio"]["sampling_rate"]
    with torch.no_grad():
        for batch in loader:
            mel = batch["mel"].to(device)
            outputs = model(mel)
            psi = outputs["psi"].cpu().numpy()
            for i, name in enumerate(PARAM_ORDER):
                pred_buffers[name].extend(psi[:, i].tolist())
            # Ground truth from EGG analysis.
            egg_batch = batch["egg_signal"].cpu().numpy()
            for j in range(egg_batch.shape[0]):
                gt = _extract_ground_truth_from_egg(egg_batch[j], sampling_rate)
                for name in PARAM_ORDER:
                    target_buffers[name].append(gt[name])

    predictions = {k: np.asarray(v) for k, v in pred_buffers.items()}
    targets = {k: np.asarray(v) for k, v in target_buffers.items()}
    return physiological_estimation_metrics(predictions, targets)
