"""
Zero-EGG inference.

Implements Equation (15) of the manuscript:

    y_hat, psi_hat, phi_hat = f_theta(x)        for x being a raw waveform
                                                without any EGG signal.

At inference time the EGG modality is unavailable. PhysioVox falls back
to a single waveform input, runs the encoder + two branches, and returns
the technique prediction together with the five physiological parameters
and the LPC filter parameters.
"""

from pathlib import Path
from typing import Any, Dict, Optional

import torch
import torchaudio

from data_processing import FeaturePipeline
from losses.causal import VOCALSET_TECHNIQUES
from models import PhysioVoxModel


class PhysioVoxPredictor:
    """High-level inference wrapper."""

    def __init__(
        self,
        config: Dict[str, Any],
        checkpoint_path: str,
        device: Optional[torch.device] = None,
    ) -> None:
        self.config = config
        self.device = device or torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
        self.feature_pipeline = FeaturePipeline(config)

        self.model = PhysioVoxModel(config).to(self.device)
        state = torch.load(checkpoint_path, map_location=self.device)
        if "model_state" in state:
            self.model.load_state_dict(state["model_state"])
        else:
            self.model.load_state_dict(state)
        self.model.eval()

    def _load_waveform(self, path: str) -> torch.Tensor:
        waveform, sr = torchaudio.load(path)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        target_sr = self.config["audio"]["sampling_rate"]
        if sr != target_sr:
            waveform = torchaudio.transforms.Resample(sr, target_sr)(waveform)
        return waveform.squeeze(0)

    @torch.no_grad()
    def predict(
        self,
        audio_input,
        return_waveform: bool = False,
    ) -> Dict[str, Any]:
        """
        Args:
            audio_input: file path (str / Path), 1-D tensor or numpy array.
            return_waveform: whether to also return the reconstructed speech.
        Returns:
            Dictionary containing:
                'technique'         : predicted technique name
                'technique_index'   : integer class index (0..16)
                'class_probabilities': (17,) probability vector
                'psi'               : dict with named physiological parameters
                'formants'          : list of four formant centre frequencies
                'reconstructed'     : reconstructed speech (if requested)
        """
        if isinstance(audio_input, (str, Path)):
            waveform = self._load_waveform(str(audio_input))
        else:
            waveform = torch.as_tensor(audio_input, dtype=torch.float32)

        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        waveform = waveform.to(self.device)

        mel = self.feature_pipeline.extract_mel(waveform)

        outputs = self.model(mel)
        probs = torch.softmax(outputs["logits"], dim=-1).squeeze(0)
        idx = int(torch.argmax(probs).item())

        result: Dict[str, Any] = {
            "technique": VOCALSET_TECHNIQUES[idx],
            "technique_index": idx,
            "class_probabilities": probs.cpu().tolist(),
            "psi": {
                name: float(value.squeeze(0).cpu().item())
                for name, value in outputs["psi_dict"].items()
            },
            "formants": outputs["formants"].squeeze(0).cpu().tolist(),
            "lpc_coeffs": outputs["lpc_coeffs"].squeeze(0).cpu().tolist(),
        }
        if return_waveform:
            result["reconstructed"] = outputs["reconstructed"].squeeze(0).cpu().numpy()
        return result

    def batch_predict(
        self, audio_files,
    ):
        """Convenience wrapper for processing a list of audio file paths."""
        return [self.predict(path) for path in audio_files]
