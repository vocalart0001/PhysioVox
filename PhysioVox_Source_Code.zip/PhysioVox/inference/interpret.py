"""
Pedagogical Interpretation of Physiological Parameters.

Translates the five-dimensional physiological output {Oq, Sq, Na, Rd, F0}
of PhysioVox into actionable pedagogical descriptions aligned with the
vocal-pedagogy vocabulary documented in Section 3.4 and Section 4.5 of
the manuscript:

    Oq (open quotient)              -> vocal-fold closure degree
    Sq (speed quotient)             -> closure symmetry
    Na (normalised amplitude)       -> glottal impact strength
    Rd (return-phase quotient)      -> onset softness
    F0 modulation depth & frequency -> vibrato amplitude and rate
    F1 (first formant)              -> vowel openness / belt resonance
"""

from typing import Any, Dict, List

import numpy as np


# Operating points used for diagnosing each pedagogical phenomenon.
DEFAULT_THRESHOLDS: Dict[str, Any] = {
    "vibrato_rate_hz": (5.0, 7.0),
    "vibrato_depth_min": 0.05,
    "breathy_oq_min": 0.5,
    "breathy_na_max": 0.10,
    "vocal_fry_jitter_min": 0.03,
    "vocal_fry_f0_max": 80.0,
    "belt_f1_min": 750.0,
    "soft_onset_rd_min": 0.18,
    "hard_onset_rd_max": 0.05,
}


class PedagogicalInterpreter:
    """Converts physiological estimates into pedagogical guidance text."""

    def __init__(self, thresholds: Dict[str, Any] = None) -> None:
        self.thresholds = {**DEFAULT_THRESHOLDS, **(thresholds or {})}

    # ----- Individual diagnostic primitives -------------------------------

    def _closure_description(self, oq: float) -> str:
        if oq < 0.40:
            return "tight closure with extended closed phase, suitable for projection"
        if oq < 0.55:
            return "balanced closure with healthy adduction"
        if oq < 0.70:
            return "moderately incomplete closure, breath leakage starting to appear"
        return "incomplete closure with substantial breath leakage"

    def _symmetry_description(self, sq: float) -> str:
        if sq < 1.5:
            return "near-symmetric open phase, classic clean tone"
        if sq < 2.5:
            return "moderate asymmetry, slightly chesty timbre"
        if sq < 3.5:
            return "marked asymmetry, prominent chest resonance"
        return "extremely steep falling slope, push-style production"

    def _impact_description(self, na: float) -> str:
        if na < 0.10:
            return "very soft glottal impact"
        if na < 0.18:
            return "moderate glottal impact"
        if na < 0.25:
            return "strong glottal impact"
        return "very strong, potentially fatiguing impact"

    def _onset_description(self, rd: float) -> str:
        if rd < self.thresholds["hard_onset_rd_max"]:
            return "hard onset, abrupt phonation start"
        if rd < self.thresholds["soft_onset_rd_min"]:
            return "smooth onset with controlled glottal start"
        return "soft onset with breath-driven start"

    def _vibrato_description(
        self, f0_modulation_rate: float, f0_modulation_depth: float
    ) -> str:
        low, high = self.thresholds["vibrato_rate_hz"]
        rate_in_band = low <= f0_modulation_rate <= high
        depth_strong = f0_modulation_depth >= self.thresholds["vibrato_depth_min"]
        if rate_in_band and depth_strong:
            return (
                f"healthy vibrato at {f0_modulation_rate:.1f} Hz with "
                f"{100 * f0_modulation_depth:.1f}% amplitude"
            )
        if rate_in_band and not depth_strong:
            return "vibrato rate is correct but amplitude is shallow"
        if not rate_in_band and depth_strong:
            return f"vibrato rate {f0_modulation_rate:.1f} Hz is outside the 5-7 Hz target"
        return "no clear vibrato detected, tone is straight"

    def _formant_description(self, f1: float) -> str:
        if f1 < 400.0:
            return "closed vowel shape, restricted oral aperture"
        if f1 < self.thresholds["belt_f1_min"]:
            return "neutral vowel shape with balanced oral aperture"
        return "high first formant indicating belt resonance"

    # ----- Composite assessment ------------------------------------------

    def interpret(
        self,
        psi: Dict[str, float],
        formants: List[float],
        f0_modulation_rate: float = 0.0,
        f0_modulation_depth: float = 0.0,
        period_jitter: float = 0.0,
    ) -> Dict[str, Any]:
        """
        Returns a dictionary containing per-parameter pedagogical descriptions
        and a free-text overall recommendation.
        """
        descriptions = {
            "closure": self._closure_description(psi["Oq"]),
            "symmetry": self._symmetry_description(psi["Sq"]),
            "impact": self._impact_description(psi["Na"]),
            "onset": self._onset_description(psi["Rd"]),
            "vibrato": self._vibrato_description(f0_modulation_rate, f0_modulation_depth),
            "formant": self._formant_description(float(formants[0]) if formants else 0.0),
        }

        diagnostics: List[str] = []
        if psi["Oq"] >= self.thresholds["breathy_oq_min"] and psi["Na"] <= self.thresholds["breathy_na_max"]:
            diagnostics.append("breathy phonation pattern")
        if period_jitter >= self.thresholds["vocal_fry_jitter_min"] and psi["F0"] <= self.thresholds["vocal_fry_f0_max"]:
            diagnostics.append("vocal-fry pattern with significant period jitter")
        if formants and float(formants[0]) >= self.thresholds["belt_f1_min"]:
            diagnostics.append("belt resonance with elevated first formant")
        if not diagnostics:
            diagnostics.append("balanced phonation, no notable irregularity")

        recommendation = self._recommend(psi, diagnostics, f0_modulation_depth)
        return {
            "psi": psi,
            "descriptions": descriptions,
            "diagnostics": diagnostics,
            "recommendation": recommendation,
        }

    def _recommend(
        self,
        psi: Dict[str, float],
        diagnostics: List[str],
        vibrato_depth: float,
    ) -> str:
        recs: List[str] = []
        if "breathy" in " ".join(diagnostics):
            recs.append(
                "increase glottal adduction through controlled stretch-and-press exercises; "
                "target an open quotient below 0.55"
            )
        if "vocal-fry" in " ".join(diagnostics):
            recs.append(
                "raise pitch into modal register and stabilise period regularity "
                "using sustained legato exercises"
            )
        if "belt" in " ".join(diagnostics):
            recs.append(
                "monitor laryngeal tension carefully; complement chest-mix coordination "
                "with twang-based formant tuning"
            )
        if vibrato_depth < self.thresholds["vibrato_depth_min"]:
            recs.append(
                "introduce gentle pitch oscillation drills to develop natural vibrato "
                "within the 5-7 Hz band"
            )
        if not recs:
            recs.append(
                "maintain current phonation balance and continue stylistic refinement"
            )
        return " ".join(recs)
