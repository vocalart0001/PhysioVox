"""
End-to-end figure reproduction script.

Generates every figure reported in the manuscript:
    Figure 7:  t-SNE cross-domain and 17-class embedding visualisation
    Figure 8:  17 x 17 confusion matrix on VocalSet
    Figure 9:  Cross-dataset Macro-F1 radar (six methods, three datasets)
    Figure 10: Module ablation contribution bar chart with Delta-Acc
    Figure 11: Loss-weight sensitivity heatmap (lambda_phys x lambda_caus)
    Figure 12: Five-dimensional physiological radar for three pedagogical cases

All figures are saved as 300 DPI PNGs under results/figures/.
"""

import sys
from pathlib import Path
from typing import List, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from visualization import (
    plot_figure_1,
    plot_figure_6,
    plot_figure_7,
    plot_figure_8,
    plot_figure_9,
    plot_figure_10,
    plot_figure_11,
    plot_figure_12,
)


FIGURE_FUNCTIONS = [
    ("Figure 1  (architecture diagram)",     plot_figure_1),
    ("Figure 6  (main results bar chart)",   plot_figure_6),
    ("Figure 7  (t-SNE embedding)",          plot_figure_7),
    ("Figure 8  (17 x 17 confusion matrix)", plot_figure_8),
    ("Figure 9  (cross-dataset radar)",      plot_figure_9),
    ("Figure 10 (ablation bar chart)",       plot_figure_10),
    ("Figure 11 (sensitivity heatmap)",      plot_figure_11),
    ("Figure 12 (pedagogical radar)",        plot_figure_12),
]


def main() -> List[Tuple[str, str]]:
    print("=" * 70)
    print("PhysioVox figure reproduction pipeline")
    print("=" * 70)

    generated: List[Tuple[str, str]] = []
    for label, plotter in FIGURE_FUNCTIONS:
        out_path = plotter()
        generated.append((label, out_path))
        size_kb = Path(out_path).stat().st_size / 1024.0
        print(f"  [OK] {label}: {out_path}  ({size_kb:.1f} KB)")

    print("=" * 70)
    print(f"Generated {len(generated)} figures under results/figures/")
    print("=" * 70)
    return generated


if __name__ == "__main__":
    main()
