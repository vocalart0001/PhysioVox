"""Entry-point scripts for PhysioVox training, evaluation, and figure reproduction."""
