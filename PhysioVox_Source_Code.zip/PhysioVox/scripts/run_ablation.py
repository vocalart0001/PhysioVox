"""
Entry point for the systematic ablation suite.

Usage:
    python scripts/run_ablation.py --config configs/default.yaml \
        --ablation configs/ablation.yaml \
        --vocalset /path/to/vocalset \
        --pretrained results/checkpoints/pretrain_best.pt
"""

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from evaluation.ablation import loss_weight_sensitivity, run_ablation_suite


def main() -> None:
    parser = argparse.ArgumentParser(
        description="PhysioVox ablation experiment runner"
    )
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument("--ablation", type=str, default="configs/ablation.yaml")
    parser.add_argument("--vocalset", type=str, required=True)
    parser.add_argument("--pretrained", type=str, default=None)
    parser.add_argument("--mode", choices=["modules", "sensitivity", "both"],
                        default="both")
    parser.add_argument(
        "--output", type=str, default="results/tables/ablation_report.json"
    )
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        base_config = yaml.safe_load(fh)
    with open(args.ablation, "r", encoding="utf-8") as fh:
        ablation_config = yaml.safe_load(fh)

    report: dict = {}
    if args.mode in ("modules", "both"):
        report["module_ablation"] = run_ablation_suite(
            base_config=base_config,
            ablation_config=ablation_config,
            vocalset_root=args.vocalset,
            pretrained_checkpoint=args.pretrained,
        )
    if args.mode in ("sensitivity", "both"):
        report["loss_weight_sensitivity"] = loss_weight_sensitivity(
            base_config=base_config,
            ablation_config=ablation_config,
            vocalset_root=args.vocalset,
            pretrained_checkpoint=args.pretrained,
        )

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, default=str)
    print(f"Ablation report saved to: {args.output}")


if __name__ == "__main__":
    main()
