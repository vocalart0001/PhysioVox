"""
Generates the final consolidated evaluation report.

Reads the paper-aligned results JSON and produces:
    - results/tables/evaluation_report.json  (overall summary)
    - results/tables/main_results.csv        (six-method comparison)
    - results/tables/ablation.csv            (six-variant ablation)
    - results/tables/physiological.csv       (5-D parameter accuracy)
    - results/tables/pedagogical_cases.csv   (three case studies)
"""

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> None:
    results_path = ROOT / "results/tables/paper_results.json"
    output_dir = ROOT / "results/tables"
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(results_path, "r", encoding="utf-8") as fh:
        results = json.load(fh)

    # -- Main results CSV (Tables 3 + 4) ---------------------------------
    main_csv = output_dir / "main_results.csv"
    methods = ["MPS-SVM", "ResNet50-Mel", "CRNN", "HuBERT-Base-FT",
               "wav2vec2-LARGE-FT", "PhysioVox"]
    datasets = ["VocalSet", "NHSS", "OpenSinger"]
    with open(main_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Method", "Dataset", "Accuracy", "Macro-F1", "Weighted-F1"])
        for method in methods:
            for ds in datasets:
                row = results["main_results"][ds][method]
                writer.writerow([
                    method, ds,
                    f"{row['accuracy']:.3f}",
                    f"{row['macro_f1']:.3f}",
                    f"{row['weighted_f1']:.3f}",
                ])

    # -- Ablation CSV (Table 5) ------------------------------------------
    ablation_csv = output_dir / "ablation.csv"
    variant_order = [
        "Full", "w/o Differentiable LF", "w/o EGG Pretraining",
        "w/o Causal Loss", "w/o Decoupling Regularization", "Backbone Only",
    ]
    with open(ablation_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Variant", "Accuracy", "Macro-F1", "DeltaAcc"])
        for variant in variant_order:
            row = results["ablation_results"][variant]
            writer.writerow([
                variant,
                f"{row['accuracy']:.3f}",
                f"{row['macro_f1']:.3f}",
                f"{row['delta_acc']:+.3f}",
            ])

    # -- Physiological accuracy CSV (Table 6) ----------------------------
    physio_csv = output_dir / "physiological.csv"
    with open(physio_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Parameter", "MAE", "RMSE", "Pearson r"])
        for name in ("Oq", "Sq", "Na", "Rd", "F0"):
            row = results["physiological_metrics"][name]
            writer.writerow([
                name,
                f"{row['mae']:.4f}",
                f"{row['rmse']:.4f}",
                f"{row['pearson_r']:.3f}",
            ])

    # -- Pedagogical cases CSV -------------------------------------------
    cases_csv = output_dir / "pedagogical_cases.csv"
    with open(cases_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "Case", "Label", "Oq", "Sq", "Na", "Rd", "F0 (Hz)",
            "Vibrato rate (Hz)", "Period jitter",
            "Diagnostic", "Recommendation",
        ])
        for case in results["pedagogical_cases"]:
            psi = case["psi"]
            writer.writerow([
                case["case_id"], case["label"],
                f"{psi['Oq']:.2f}", f"{psi['Sq']:.2f}", f"{psi['Na']:.2f}",
                f"{psi['Rd']:.2f}", f"{psi['F0']:.1f}",
                f"{case['F0_modulation_rate_hz']:.1f}",
                f"{case['period_jitter']:.3f}",
                case["diagnostic"],
                case["recommendation"],
            ])

    # -- Consolidated evaluation report ----------------------------------
    summary = {
        "vocalset_17class": results["main_results"]["VocalSet"]["PhysioVox"],
        "cross_domain": {
            "NHSS": results["main_results"]["NHSS"]["PhysioVox"],
            "OpenSinger": results["main_results"]["OpenSinger"]["PhysioVox"],
        },
        "ablation_summary": results["ablation_results"],
        "physiological_summary": results["physiological_metrics"],
        "optimal_loss_weights": results["sensitivity_grid"]["optimal_point"],
    }
    report_path = output_dir / "evaluation_report.json"
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)

    print("Generated result tables:")
    for p in [main_csv, ablation_csv, physio_csv, cases_csv, report_path]:
        size_kb = p.stat().st_size / 1024
        print(f"  {p.relative_to(ROOT)}  ({size_kb:.1f} KB)")


if __name__ == "__main__":
    main()
