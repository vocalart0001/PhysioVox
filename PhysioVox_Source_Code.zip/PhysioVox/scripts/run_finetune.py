"""
Entry point for Stage 2 VocalSet fine-tuning.

Usage:
    python scripts/run_finetune.py --config configs/default.yaml \
        --vocalset /path/to/vocalset \
        --pretrained results/checkpoints/pretrain_best.pt
"""

import argparse
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from training import run_finetune


def main() -> None:
    parser = argparse.ArgumentParser(
        description="PhysioVox Stage-2 VocalSet fine-tuning"
    )
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument("--vocalset", type=str, required=True,
                        help="Root directory of the VocalSet corpus")
    parser.add_argument("--pretrained", type=str, default=None,
                        help="Path to a pretraining checkpoint (theta_s*)")
    parser.add_argument("--fold", type=int, default=0,
                        help="5-fold cross-validation fold index (0..4)")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        config = yaml.safe_load(fh)

    outcome = run_finetune(
        config=config,
        vocalset_root=args.vocalset,
        pretrained_checkpoint=args.pretrained,
        fold_index=args.fold,
    )
    print(f"Fold-{args.fold} fine-tuning complete. Checkpoint: {outcome['checkpoint']}")


if __name__ == "__main__":
    main()
