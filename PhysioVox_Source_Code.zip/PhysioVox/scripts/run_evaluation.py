"""
Entry point for end-to-end evaluation of a fine-tuned PhysioVox checkpoint.

Usage:
    python scripts/run_evaluation.py --config configs/default.yaml \
        --checkpoint results/checkpoints/finetune_best.pt \
        --vocalset /path/to/vocalset \
        --nhss /path/to/nhss \
        --opensinger /path/to/opensinger \
        --voiced /path/to/voiced --svd /path/to/svd
"""

import argparse
import json
import sys
from pathlib import Path

import torch
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_processing import FeaturePipeline, VocalSetDataset, build_dataloader
from evaluation import (
    classification_metrics,
    collect_predictions,
    evaluate_cross_domain,
    evaluate_physiological_accuracy,
)
from models import PhysioVoxModel


def main() -> None:
    parser = argparse.ArgumentParser(
        description="PhysioVox end-to-end evaluation pipeline"
    )
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--vocalset", type=str, required=True)
    parser.add_argument("--nhss", type=str, default="")
    parser.add_argument("--opensinger", type=str, default="")
    parser.add_argument("--voiced", type=str, default="")
    parser.add_argument("--svd", type=str, default="")
    parser.add_argument(
        "--output", type=str, default="results/tables/evaluation_report.json"
    )
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        config = yaml.safe_load(fh)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = PhysioVoxModel(config).to(device)
    state = torch.load(args.checkpoint, map_location=device)
    if "model_state" in state:
        model.load_state_dict(state["model_state"])
    else:
        model.load_state_dict(state)
    model.eval()

    report: dict = {"checkpoint": args.checkpoint}

    # ---- VocalSet 17-class evaluation ----------------------------------
    feature_pipeline = FeaturePipeline(config)
    val_dataset = VocalSetDataset(
        root_dir=args.vocalset,
        target_sampling_rate=config["audio"]["sampling_rate"],
        segment_seconds=config["audio"]["segment_seconds"],
        feature_pipeline=feature_pipeline,
    )
    val_loader = build_dataloader(
        val_dataset,
        batch_size=config["training"]["finetune"]["batch_size"],
        num_workers=config["experiment"]["num_workers"],
        shuffle=False,
    )
    preds = collect_predictions(model, val_loader, device)
    if preds["logits"].size > 0:
        y_pred = preds["logits"].argmax(axis=-1)
        report["vocalset_17class"] = classification_metrics(preds["labels"], y_pred)

    # ---- Cross-domain evaluation ---------------------------------------
    if args.nhss or args.opensinger:
        report["cross_domain"] = evaluate_cross_domain(
            model=model,
            config=config,
            nhss_root=args.nhss,
            opensinger_root=args.opensinger,
            device=device,
        )

    # ---- Physiological estimation accuracy -----------------------------
    if args.voiced or args.svd:
        report["physiological"] = evaluate_physiological_accuracy(
            model=model,
            config=config,
            voiced_root=args.voiced,
            svd_root=args.svd,
            device=device,
        )

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    print(f"Evaluation report saved to: {args.output}")


if __name__ == "__main__":
    main()
