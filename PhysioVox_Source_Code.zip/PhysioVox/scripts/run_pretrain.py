"""
Entry point for Stage 1 EGG-driven cross-domain pretraining.

Usage:
    python scripts/run_pretrain.py --config configs/default.yaml \
        --voiced /path/to/voiced --svd /path/to/svd
"""

import argparse
import sys
from pathlib import Path

import yaml

# Make the project root importable when launched from any working directory.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from training import run_pretrain


def main() -> None:
    parser = argparse.ArgumentParser(
        description="PhysioVox Stage-1 EGG-driven cross-domain pretraining"
    )
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument("--voiced", type=str, required=True,
                        help="Root directory of the VOICED corpus")
    parser.add_argument("--svd", type=str, required=True,
                        help="Root directory of the SVD corpus")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        config = yaml.safe_load(fh)

    outcome = run_pretrain(
        config=config,
        voiced_root=args.voiced,
        svd_root=args.svd,
    )
    print(f"Pretraining complete. Best checkpoint: {outcome['checkpoint']}")


if __name__ == "__main__":
    main()
